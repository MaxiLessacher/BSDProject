package pkgDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Vector;

import pkgClasses.Rechnung;
import pkgClasses.Wasserstandsmeldung;



public class Database {
	private Connection conn;
	private Vector<Wasserstandsmeldung> vecWasserstandsmeldung = new Vector<Wasserstandsmeldung>();
	private Vector<Integer> vecWasserzaehler = new Vector<Integer>();
	
	private String intConnString = "jdbc:oracle:thin:@192.168.128.151:1521:ora11g";
	private String extConnString = "jdbc:oracle:thin:@212.152.179.117:1521:ora11g";
	private String user="d5b30";
	private String pwd="d5b30";
	private boolean intern = true;
	private Rechnung rechnung = new Rechnung();

	private static Database instance;
	   
	public static Database getInstance () {
	    if (Database.instance == null) {
	    	Database.instance = new Database ();
	    }
	    return Database.instance;
	}

	public void createConnection() throws SQLException {
		String connStrg = intConnString;
		if (!intern) {
			connStrg = extConnString;
		}
		connStrg = extConnString;
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		this.conn = DriverManager.getConnection(connStrg, user, pwd);
	}
	
	public void setIntern(boolean intern) {
		this.intern = intern;
	}
	
	public boolean getIntern() {
		return intern;
	}
	
	private ResultSet getData(String statement) throws SQLException{
		ResultSet retValue = null;
		try{
		createConnection();
		PreparedStatement stmt = conn.prepareStatement(statement,	ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
		retValue  = stmt.executeQuery();
		}
		catch(Exception e){
			System.out.println("Error in get Data");
			retValue =  null;
		}
		return retValue;
	}

	public void loadWasserzaehlerFromDb() throws SQLException {
		this.vecWasserzaehler.clear();
		ResultSet rs = getData("select zaehler_nr from wasserzaehler");
		while (rs.next()) {
			vecWasserzaehler.add(rs.getInt(1));
		}
	}
	
	public void loadWasserstandsmeldungFromDb() throws SQLException {
		this.vecWasserstandsmeldung.clear();
		ResultSet rs = getData("select * from wasserstandsmeldung");
		while (rs.next()) {
			this.addWasserstandsmeldung(new Wasserstandsmeldung(rs.getDate("datum"), rs.getInt("zaehler_nr"), rs.getInt("neuZaehlerstand")));
		}
	}

	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public Vector<Wasserstandsmeldung> getVecWasserstandsmeldung() {
		return vecWasserstandsmeldung;
	}

	public void setVecWasserstandsmeldung(Vector<Wasserstandsmeldung> vecWasserstandsmeldung) {
		this.vecWasserstandsmeldung = vecWasserstandsmeldung;
	}

	public void insertWasserstandsmeldung(Wasserstandsmeldung newWm) throws SQLException {
		createConnection();
		try {
			java.sql.Date date = new java.sql.Date(newWm.getDatum().getTime());
			PreparedStatement stmt = null;
			stmt = conn.prepareStatement("INSERT INTO Wasserstandsmeldung VALUES(?,?,?)", ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			stmt.setDate(1, date);
			stmt.setInt(2, newWm.getZaehlerNr());
			stmt.setInt(3, newWm.getNeuZaehlerstand());
			stmt.executeUpdate();
			/*stmt = conn.prepareStatement("UPDATE WASSERZAEHLER SET zaehlerstand = ? where zaehler_nr = ?", ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			stmt.setInt(1, newWm.getNeuZaehlerstand());
			stmt.setInt(2, newWm.getZaehlerNr());
			stmt.executeUpdate();*/
			}
			catch (Exception e) {
				System.out.println("error occured in insertVerwaltungspersonal");
				e.printStackTrace();
			}
	}
	/*
	public void updateWasserstandsmeldung(Wasserstandsmeldung oldWm,Wasserstandsmeldung newWm) throws SQLException {
		Iterator<Wasserstandsmeldung> itrWm = vecWasserstandsmeldung.iterator();
		while (itrWm.hasNext()) {
			Wasserstandsmeldung tempWm = itrWm.next();
			if (tempWm.compareTo(oldWm) == 0) {
				tempWm = newWm;
			}
		}
		createConnection();
		try {
			java.sql.Date oldDate = new java.sql.Date(oldWm.getDatum().getTime());
			java.sql.Date newDate = new java.sql.Date(newWm.getDatum().getTime());
			PreparedStatement stmt = null;
			stmt = conn.prepareStatement("update wasserstandsmeldung set zaehler_nr=?, neuZaehlerstand = ?, date=? where date = ? AND zaehler_nr = ?", ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			stmt.setInt(1, newWm.getZaehlerNr());
			stmt.setInt(2, newWm.getNeuZaehlerstand());
			stmt.setDate(3, newDate);
			stmt.setDate(4, oldDate);
			stmt.setInt(5, oldWm.getZaehlerNr());
			stmt.executeUpdate();
			}
			catch (Exception e) {
				System.out.println("error occured in updateHaushalt");
				e.printStackTrace();
			}
	}*/
	
	public void addWasserstandsmeldung(Wasserstandsmeldung wasserstandsmeldung) {
		this.vecWasserstandsmeldung.add(wasserstandsmeldung);
	}
	
	public void removeWasserstandsmeldung(Wasserstandsmeldung rem) throws Exception {
		vecWasserstandsmeldung.remove(rem);
	}
	
	public boolean wmExists(Wasserstandsmeldung Wm) {
		boolean retValue = false;
		Iterator<Wasserstandsmeldung> itrWm = vecWasserstandsmeldung.iterator();
		while (itrWm.hasNext()) {
			Wasserstandsmeldung tempWm = itrWm.next();
			if (tempWm.compareTo(Wm) == 0) {
				retValue = true;
			}
		}
		return retValue;
	}

	public Vector<Integer> getVecWasserzaehler() {
		return vecWasserzaehler;
	}
	
	public double getPreis() {
		double retValue = 0;
		try {
			ResultSet rs = getData("select preis from preis");
			while(rs.next()) {
				retValue = rs.getFloat(1);
			}
			System.out.println(retValue + " *****************");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return retValue;
	}
	
	public void createRechnung(Wasserstandsmeldung wm) {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			String date = df.format(wm.getDatum());
			ResultSet rs = getData("select h.hh_id, m.name, wz.zaehlerstand, "
					+ "wm.neuZaehlerstand, wm.datum from haushalt h "
					+ "join wasserzaehler wz on h.hh_id = wz.hh_id "
					+ "join wasserstandsmeldung wm on wm.zaehler_nr = wz.zaehler_nr "
					+ "join mitglieder m on m.hh_id = h.hh_id "
					+ "where wz.zaehler_nr = " + wm.getZaehlerNr() + " AND m.hh_vorstand = 1 AND to_char(datum,'yyyy-MM-dd') = '" + date +"'");
			while(rs.next()) {
				rechnung = new Rechnung(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4),
						new java.util.Date(rs.getDate(5).getTime()));
			}
			rechnung.setPreis(getPreis());
			rechnung.setVerbrauch(rechnung.getAktZaehlerstand()-rechnung.getAltZaehlerstand());
			rechnung.setKosten(rechnung.getPreis()*rechnung.getVerbrauch());
			System.out.println(rechnung.getKosten());
			System.out.println(rechnung.getPreis());
			System.out.println(rechnung.getDatum()+"");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public Rechnung getRechung() {
		return this.rechnung;
	}
}