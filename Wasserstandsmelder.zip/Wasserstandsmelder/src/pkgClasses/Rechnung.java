package pkgClasses;

import java.util.Date;

public class Rechnung {
	private int HH_ID;
	private String HH_Vorstand;
	private int altZaehlerstand;
	private int aktZaehlerstand;
	private double preis;
	private double kosten;
	private int verbrauch;
	private Date datum;
	
	public Rechnung() {
		super();
	}
	
	public Rechnung(int hh_id, String hh_Vorstand, int altZaehlerstand,
			int aktZaehlerstand, Date datum) {
		this.HH_ID = hh_id;
		this.HH_Vorstand = hh_Vorstand;
		this.altZaehlerstand = altZaehlerstand;
		this.aktZaehlerstand = aktZaehlerstand;
		this.datum = datum;
	}
	
	public Rechnung(int hH_ID, String hH_Vorstand, int altZaehlerstand,
			int aktZaehlerstand, double preis, double kosten, int verbrauch,
			Date datum) {
		super();
		HH_ID = hH_ID;
		HH_Vorstand = hH_Vorstand;
		this.altZaehlerstand = altZaehlerstand;
		this.aktZaehlerstand = aktZaehlerstand;
		this.preis = preis;
		this.kosten = kosten;
		this.verbrauch = verbrauch;
		this.datum = datum;
	}
	public int getHH_ID() {
		return HH_ID;
	}
	public void setHH_ID(int hH_ID) {
		HH_ID = hH_ID;
	}
	public String getHH_Vorstand() {
		return HH_Vorstand;
	}
	public void setHH_Vorstand(String hH_Vorstand) {
		HH_Vorstand = hH_Vorstand;
	}
	public int getAltZaehlerstand() {
		return altZaehlerstand;
	}
	public void setAltZaehlerstand(int altZaehlerstand) {
		this.altZaehlerstand = altZaehlerstand;
	}
	public int getAktZaehlerstand() {
		return aktZaehlerstand;
	}
	public void setAktZaehlerstand(int aktZaehlerstand) {
		this.aktZaehlerstand = aktZaehlerstand;
	}
	public double getPreis() {
		return preis;
	}
	public void setPreis(double d) {
		this.preis = d;
	}
	public double getKosten() {
		return kosten;
	}
	public void setKosten(double kosten) {
		this.kosten = kosten;
	}
	public int getVerbrauch() {
		return verbrauch;
	}
	public void setVerbrauch(int verbrauch) {
		this.verbrauch = verbrauch;
	}
	public Date getDatum() {
		return datum;
	}
	public void setDatum(Date datum) {
		this.datum = datum;
	}
}
