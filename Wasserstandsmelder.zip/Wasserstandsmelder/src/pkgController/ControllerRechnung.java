package pkgController;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;

import pkgClasses.Rechnung;
import pkgDatabase.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class ControllerRechnung implements Initializable {
	@FXML
	private Label lblHH_ID;
	@FXML
	private Label lblHH_Vorstand;
	@FXML
	private Label lblAktZaehlerstand;
	@FXML
	private Label lblKosten;
	@FXML
	private Label lblDatum;
	@FXML
	private Label lblPreis;
	@FXML
	private Label lblAltZaehlerstand;
	@FXML
	private Label lblVerbrauch;
	
	private Database database = Database.getInstance();
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			Rechnung rechnung = database.getRechung();
			lblHH_ID.setText(rechnung.getHH_ID()+"");
			lblHH_Vorstand.setText(rechnung.getHH_Vorstand());
			lblPreis.setText(rechnung.getPreis()+"");
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			String date = df.format(rechnung.getDatum());
			lblDatum.setText(date+"");
			lblAltZaehlerstand.setText(rechnung.getAltZaehlerstand()+"");
			lblAktZaehlerstand.setText(rechnung.getAktZaehlerstand()+"");
			lblVerbrauch.setText(rechnung.getVerbrauch()+"");
			lblKosten.setText(rechnung.getKosten()+"€");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
