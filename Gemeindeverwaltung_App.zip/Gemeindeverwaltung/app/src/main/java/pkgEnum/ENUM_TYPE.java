package pkgEnum;

/**
 * Created by David on 20.01.2016.
 */
public enum ENUM_TYPE {
    UPDATE,
    ADD
}
