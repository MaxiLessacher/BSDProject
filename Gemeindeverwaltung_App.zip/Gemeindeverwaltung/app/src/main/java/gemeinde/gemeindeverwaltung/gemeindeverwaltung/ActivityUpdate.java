package gemeinde.gemeindeverwaltung.gemeindeverwaltung;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Adresse;
import pkgClasses.Haushalt;
import pkgClasses.Mitglied;
import pkgClasses.Ort;
import pkgClasses.Strasse;
import pkgClasses.Verwaltungspersonal;
import pkgClasses.Wasserstandsmeldung;
import pkgClasses.Wasserzaehler;
import pkgDatabase.Database;

public class ActivityUpdate extends AppCompatActivity implements View.OnClickListener{
    private Button btnUpdateInfo = null,
            btnCancelUpdate = null;
    private TextView lblArg1,
            lblArg2,
            lblArg3,
            lblArg4,
            lblArg5,
            lblArg6,
            lblArg7,
            lblArg8;
    private EditText txtArg1,
            txtArg2,
            txtArg3,
            txtArg4;
    private CheckBox chbox1,
            chbox2;
    private Spinner  spinner1,
            spinner2,
            spinner3;
    private DatePicker datePicker;
    private TableLayout tableUpdate;
    private Database database=null;
    private Object object = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        database = Database.getInstance(getBaseContext());
        object = getIntent().getExtras().get("Caller");
        if (object != null) {
            getAllViews();
        }
        else {
            closeActivity();
        }
    }

    private void getAllViews() {
        btnUpdateInfo = (Button) this.findViewById(R.id.btnUpdateInfo);
        btnCancelUpdate = (Button) this.findViewById(R.id.btnCancelUpdate);

        btnUpdateInfo.setOnClickListener(this);
        btnCancelUpdate.setOnClickListener(this);

        tableUpdate = (TableLayout) this.findViewById(R.id.tableUpdate);

        try {
            if (object instanceof Ort) {
                initOrt((Ort) object);
            } else if (object instanceof Strasse) {
                initStrasse((Strasse) object);
            } else if (object instanceof Adresse) {
                initAdresse((Adresse) object);
            } else if (object instanceof Haushalt) {
                initHaushalt((Haushalt) object);
            } else if (object instanceof Mitglied) {
                initMitglied((Mitglied) object);
            } else if (object instanceof Wasserstandsmeldung) {
                initWasserstandsmeldung((Wasserstandsmeldung) object);
            } else if (object instanceof Wasserzaehler) {
                initWasserzaehler((Wasserzaehler) object);
            } else if (object instanceof Verwaltungspersonal) {
                initVerwaltungspersonal((Verwaltungspersonal) object);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initOrt(Ort ort) {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg1.setText(R.string.lblPLZ);
        lblArg2.setText(R.string.lblOrt);
        txtArg1 = new EditText(this);
        txtArg2 = new EditText(this);
        txtArg1.setText(ort.getPlz() + "", TextView.BufferType.EDITABLE);
        txtArg2.setText(ort.getOrt(), TextView.BufferType.EDITABLE);
        txtArg1.setGravity(Gravity.CENTER_HORIZONTAL);
        txtArg2.setGravity(Gravity.CENTER_HORIZONTAL);
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(txtArg1);
        row2.addView(lblArg2);
        row2.addView(txtArg2);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
    }
    private void initStrasse(Strasse strasse) throws SQLException {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg1.setText(R.string.lblPLZ);
        lblArg2.setText(R.string.lblStrasse);
        txtArg1 = new EditText(this);
        spinner1 = new Spinner(this);
        txtArg1.setText(strasse.getStrasse());
        Vector<Integer> vecResult = new Vector<>();
        int pos = 0;
        for (int i = 0; i < database.getOrte().size(); i++) {
            vecResult.add(database.getOrte().get(i).getPlz());
            if (database.getOrte().get(i).getPlz() == strasse.getPlz()) {
                pos = i;
            }
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, vecResult);
        spinner1.setAdapter(adapter);
        spinner1.setSelection(pos);
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(spinner1);
        row2.addView(lblArg2);
        row2.addView(txtArg1);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
    }
    private void initAdresse(Adresse adresse) throws SQLException {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg3 = new TextView(this);
        lblArg1.setText(R.string.lblPLZ);
        lblArg2.setText(R.string.lblStrasse);
        lblArg3.setText(R.string.lblHausnummer);
        txtArg1 = new EditText(this);
        spinner1 = new Spinner(this);
        spinner2 = new Spinner(this);
        txtArg1.setText(adresse.getHausnummer()+"");
        Vector<Integer> vecResult = new Vector<>();
        int pos = 0;
        Vector<Ort> vector = database.getOrte();
        for (int i = 0; i < vector.size(); i++) {
            vecResult.add(vector.get(i).getPlz());
            if (vector.get(i).getPlz() == adresse.getPlz()) {
                pos = i;
            }
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, vecResult);
        spinner1.setAdapter(adapter);
        spinner1.setSelection(pos);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Vector<Strasse> vecStrassen = new Vector<>();
                Vector<String> vecString = new Vector<>();
                try {
                    vecStrassen = database.getStrassen(Integer.parseInt(spinner1.getSelectedItem().toString()));
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                int pos = 0;
                Adresse adresse = (Adresse) object;
                for (int i = 0; i < vecStrassen.size(); i++) {
                    vecString.add(vecStrassen.get(i).getStrasse());
                    if (vecStrassen.get(i).getStrasse().equals(adresse.getStrasse())) {
                        pos = i;
                    }
                }
                ArrayAdapter<String> adapter1 = new ArrayAdapter<>(ActivityUpdate.this, android.R.layout.simple_spinner_dropdown_item, vecString);
                spinner2.setAdapter(adapter1);
                spinner2.setSelection(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        TableRow row3 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(spinner1);
        row2.addView(lblArg2);
        row2.addView(spinner2);
        row3.addView(lblArg3);
        row3.addView(txtArg1);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
        tableUpdate.addView(row3);
    }
    private void initHaushalt(Haushalt haushalt) throws SQLException {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg3 = new TextView(this);
        lblArg4 = new TextView(this);
        lblArg5 = new TextView(this);
        lblArg6 = new TextView(this);
        lblArg7 = new TextView(this);
        lblArg8 = new TextView(this);
        lblArg1.setText(R.string.lblHH_ID);
        lblArg2.setText(R.string.lblPLZ);
        lblArg3.setText(R.string.lblStrasse);
        lblArg4.setText(R.string.lblHausnummer);
        lblArg5.setText(R.string.lblTuernummer);
        lblArg6.setText(R.string.lblWohnflaeche);
        lblArg7.setText(R.string.lblLandwirtschaft);
        lblArg8.setText(R.string.lblGarten);
        txtArg1 = new EditText(this);
        txtArg1.setText(haushalt.getHH_ID()+"");
        txtArg2 = new EditText(this);
        txtArg2.setText(haushalt.getTuernummer()+"");
        txtArg3 = new EditText(this);
        txtArg3.setText(haushalt.getWohnflaeche()+"");
        spinner1 = new Spinner(this);
        Vector<Integer> vecResult = new Vector<>();
        int pos = 0;
        Vector<Ort> vecOrt = database.getOrte();
        for (int i = 0; i < vecOrt.size(); i++) {
            vecResult.add(vecOrt.get(i).getPlz());
            if (vecOrt.get(i).getPlz() == haushalt.getPlz()) {
                pos = i;
            }
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, vecResult);
        spinner1.setAdapter(adapter);
        spinner1.setSelection(pos);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Vector<Strasse> vecStrassen = new Vector<>();
                Vector<String> vecString = new Vector<>();
                try {
                    vecStrassen = database.getStrassen(Integer.parseInt(spinner1.getSelectedItem().toString()));
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                int pos = 0;
                Haushalt haushalt = (Haushalt) object;
                for (int i = 0; i < vecStrassen.size(); i++) {
                    vecString.add(vecStrassen.get(i).getStrasse());
                    if (haushalt.getStrasse().equals(vecStrassen.get(i).getStrasse())) {
                        pos = i;
                    }
                }
                ArrayAdapter<String> adapter1 = new ArrayAdapter<>(ActivityUpdate.this, android.R.layout.simple_spinner_dropdown_item, vecString);
                spinner2.setAdapter(adapter1);
                spinner2.setSelection(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner2 = new Spinner(this);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Vector<Adresse> vecAdressen = new Vector<>();
                Vector<Integer> vecInt = new Vector<>();
                try {
                    vecAdressen = database.getAdressen(Integer.parseInt(spinner1.getSelectedItem().toString()), spinner2.getSelectedItem().toString());
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                int pos = 0;
                Haushalt haushalt = (Haushalt) object;
                for (int i = 0; i < vecAdressen.size(); i++) {
                    vecInt.add(vecAdressen.get(i).getHausnummer());
                    if (vecAdressen.get(i).getHausnummer() == haushalt.getHausnummer()) {
                        pos = i;
                    }
                }
                ArrayAdapter<Integer> adapter1 = new ArrayAdapter<>(ActivityUpdate.this, android.R.layout.simple_spinner_dropdown_item, vecInt);
                spinner3.setAdapter(adapter1);
                spinner3.setSelection(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner3 = new Spinner(this);
        chbox1 = new CheckBox(this);
        chbox1.setChecked(haushalt.isLandwirtschaft());
        chbox2 = new CheckBox(this);
        chbox2.setChecked(haushalt.isGarten());
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        TableRow row3 = new TableRow(this);
        TableRow row4 = new TableRow(this);
        TableRow row5 = new TableRow(this);
        TableRow row6 = new TableRow(this);
        TableRow row7 = new TableRow(this);
        TableRow row8 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(txtArg1);
        row2.addView(lblArg2);
        row2.addView(spinner1);
        row3.addView(lblArg3);
        row3.addView(spinner2);
        row4.addView(lblArg4);
        row4.addView(spinner3);
        row5.addView(lblArg5);
        row5.addView(txtArg2);
        row6.addView(lblArg6);
        row6.addView(txtArg3);
        row7.addView(lblArg7);
        row7.addView(chbox1);
        row8.addView(lblArg8);
        row8.addView(chbox2);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
        tableUpdate.addView(row3);
        tableUpdate.addView(row4);
        tableUpdate.addView(row5);
        tableUpdate.addView(row6);
        tableUpdate.addView(row7);
        tableUpdate.addView(row8);
    }
    private void initMitglied(Mitglied mitglied) throws SQLException {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg3 = new TextView(this);
        lblArg4 = new TextView(this);
        lblArg1.setText(R.string.lblMitgliedsID);
        lblArg2.setText(R.string.lblName);
        lblArg3.setText(R.string.lblHHVorstand);
        lblArg4.setText(R.string.lblHH_ID);
        txtArg1 = new EditText(this);
        txtArg1.setText(mitglied.getMitglieds_id()+"");
        txtArg2 = new EditText(this);
        txtArg2.setText(mitglied.getName());
        spinner1 = new Spinner(this);
        Vector<Integer> vecInt = new Vector<>();
        int pos = 0;
        for(int i = 0; i < database.getHaushalte().size(); i++) {
            vecInt.add(database.getHaushalte().get(i).getHH_ID());
            if (database.getHaushalte().get(i).getHH_ID() == mitglied.getHH_ID()) {
                pos = i;
            }
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, vecInt);
        spinner1.setAdapter(adapter);
        spinner1.setSelection(pos);
        chbox1 = new CheckBox(this);
        chbox1.setChecked(mitglied.isHH_Vorstand());
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        TableRow row3 = new TableRow(this);
        TableRow row4 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(txtArg1);
        row2.addView(lblArg2);
        row2.addView(txtArg2);
        row3.addView(lblArg3);
        row3.addView(chbox1);
        row4.addView(lblArg4);
        row4.addView(spinner1);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
        tableUpdate.addView(row3);
        tableUpdate.addView(row4);
    }
    private void initWasserzaehler(Wasserzaehler wz) throws SQLException {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg3 = new TextView(this);
        lblArg4 = new TextView(this);
        lblArg5 = new TextView(this);
        lblArg6 = new TextView(this);
        lblArg1.setText(R.string.lblZaehlerNr);
        lblArg2.setText(R.string.lblHH_ID);
        lblArg3.setText(R.string.lblZaehlerstand);
        lblArg4.setText(R.string.lblHHVorstand);
        lblArg5.setText(R.string.lblX);
        lblArg6.setText(R.string.lblY);
        txtArg1 = new EditText(this);
        txtArg1.setText(wz.getZaehler_nr()+"");
        txtArg2 = new EditText(this);
        txtArg2.setText(wz.getZaehlerstand()+"");
        txtArg3 = new EditText(this);
        txtArg3.setText(wz.getStandort_x()+"");
        txtArg4 = new EditText(this);
        txtArg4.setText(wz.getStandort_y()+"");
        spinner1 = new Spinner(this);
        Vector<Integer> vecInt = new Vector<>();
        int pos = 0;
        for(int i = 0; i < database.getHaushalte().size(); i++) {
            vecInt.add(database.getHaushalte().get(i).getHH_ID());
            if (database.getHaushalte().get(i).getHH_ID() == wz.getHH_ID()) {
                pos = i;
            }
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, vecInt);
        spinner1.setAdapter(adapter);
        spinner1.setSelection(pos);
        chbox1 = new CheckBox(this);
        chbox1.setChecked(wz.isHauptzaehler());
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        TableRow row3 = new TableRow(this);
        TableRow row4 = new TableRow(this);
        TableRow row5 = new TableRow(this);
        TableRow row6 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(txtArg1);
        row2.addView(lblArg2);
        row2.addView(spinner1);
        row3.addView(lblArg3);
        row3.addView(txtArg2);
        row4.addView(lblArg4);
        row4.addView(chbox1);
        row5.addView(lblArg5);
        row5.addView(txtArg3);
        row6.addView(lblArg6);
        row6.addView(txtArg4);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
        tableUpdate.addView(row3);
        tableUpdate.addView(row4);
        tableUpdate.addView(row5);
        tableUpdate.addView(row6);
    }
    private void initWasserstandsmeldung(Wasserstandsmeldung ws) throws SQLException {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg3 = new TextView(this);
        lblArg1.setText(R.string.lblZaehlerNr);
        lblArg2.setText(R.string.lblneuZaehlerstand);
        lblArg3.setText(R.string.lblDatum);
        txtArg1 = new EditText(this);
        txtArg1.setText(ws.getNeuZaehlerstand()+"");
        spinner1 = new Spinner(this);
        Vector<Integer> vecInt = new Vector<>();
        int pos = 0;
        for(int i = 0; i < database.getWasserzaehler().size(); i++) {
            vecInt.add(database.getWasserzaehler().get(i).getZaehler_nr());
            if (database.getWasserzaehler().get(i).getZaehler_nr() == ws.getZaehlerNr()) {
                pos = i;
            }
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, vecInt);
        spinner1.setAdapter(adapter);
        spinner1.setSelection(pos);
        datePicker = new DatePicker(this);
        datePicker.setSpinnersShown(true);
        datePicker.updateDate(Integer.parseInt(ws.getDatum().split("\\.")[2]),Integer.parseInt(ws.getDatum().split("\\.")[1])-1,Integer.parseInt(ws.getDatum().split("\\.")[0]));
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        TableRow row3 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(spinner1);
        row2.addView(lblArg2);
        row2.addView(txtArg1);
        row3.addView(lblArg3);
        row3.addView(datePicker);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
        tableUpdate.addView(row3);
    }
    private void initVerwaltungspersonal(Verwaltungspersonal vw) {
        lblArg1 = new TextView(this);
        lblArg2 = new TextView(this);
        lblArg3 = new TextView(this);
        lblArg1.setText(R.string.lblPersonalID);
        lblArg1.setText(R.string.lblName);
        lblArg1.setText(R.string.lblAbteilung);
        txtArg1 = new EditText(this);
        txtArg1.setText(vw.getPersonal_id()+"");
        txtArg2 = new EditText(this);
        txtArg2.setText(vw.getName());
        txtArg3 = new EditText(this);
        txtArg3.setText(vw.getAbteilung());
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        TableRow row3 = new TableRow(this);
        row1.addView(lblArg1);
        row1.addView(txtArg1);
        row2.addView(lblArg2);
        row2.addView(txtArg2);
        row3.addView(lblArg3);
        row3.addView(txtArg3);
        tableUpdate.addView(row1);
        tableUpdate.addView(row2);
        tableUpdate.addView(row3);
    }

    @Override
    public void onClick(View v) {
        try {
            switch (v.getId()) {
                case R.id.btnUpdateInfo:
                    if (object instanceof Ort) {
                        database.updateOrt((Ort) object, new Ort(Integer.parseInt(txtArg1.getText().toString()), txtArg2.getText().toString()));
                    } else if (object instanceof Strasse) {
                        database.updateStrasse((Strasse) object, new Strasse(Integer.parseInt(spinner1.getSelectedItem().toString()),txtArg1.getText().toString()));
                    } else if (object instanceof Adresse) {
                        database.updateAdresse((Adresse) object, new Adresse(Integer.parseInt(spinner1.getSelectedItem().toString()), spinner2.getSelectedItem().toString(), Integer.parseInt(txtArg1.getText().toString())));
                    } else if (object instanceof Haushalt) {
                        database.updateHaushalt((Haushalt) object, new Haushalt(Integer.parseInt(txtArg1.getText().toString()), Integer.parseInt(spinner1.getSelectedItem().toString()), spinner2.getSelectedItem().toString(), Integer.parseInt(spinner3.getSelectedItem().toString()), Integer.parseInt(txtArg2.getText().toString()), Integer.parseInt(txtArg3.getText().toString()), chbox1.isSelected(), chbox2.isSelected()));
                    } else if (object instanceof Mitglied) {
                        database.updateMitglied((Mitglied) object, new Mitglied(Integer.parseInt(txtArg1.getText().toString()), txtArg2.getText().toString(), chbox1.isSelected(), Integer.parseInt(spinner1.getSelectedItem().toString())));
                    } else if (object instanceof Wasserzaehler) {
                        database.updateWasserzaehler((Wasserzaehler) object, new Wasserzaehler(Integer.parseInt(txtArg1.getText().toString()), Integer.parseInt(spinner1.getSelectedItem().toString()), Integer.parseInt(txtArg2.getText().toString()), chbox1.isChecked(), Integer.parseInt(txtArg3.getText().toString()), Integer.parseInt(txtArg4.getText().toString())));
                    } else if (object instanceof Wasserstandsmeldung) {
                        String date = datePicker.getDayOfMonth() + "." + datePicker.getMonth() + "." + datePicker.getYear();
                        database.updateWasserstandsmeldung((Wasserstandsmeldung) object, new Wasserstandsmeldung(Integer.parseInt(spinner1.getSelectedItem().toString()), Integer.parseInt(txtArg1.getText().toString()),date));
                    } else if (object instanceof Verwaltungspersonal) {
                        database.updateVerwaltungspersonal((Verwaltungspersonal) object, new Verwaltungspersonal(Integer.parseInt(txtArg1.getText().toString()), txtArg2.getText().toString(), txtArg3.getText().toString()));
                    }
                case R.id.btnCancelUpdate:
                    closeActivity();
                    break;
            }
            closeActivity();
        }
        catch(Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void closeActivity() {
        this.finish();
    }
}
