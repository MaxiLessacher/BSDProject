package gemeinde.gemeindeverwaltung.gemeindeverwaltung;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;

import pkgClasses.Verwaltungspersonal;
import pkgDatabase.Database;

import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.cell_data;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.column_header;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.highlight_cell;

public class ActivityVerwaltungspersonal extends AppCompatActivity implements View.OnClickListener {
    Button btnAdd = null,
            btnUpdate = null,
            btnDelete = null;
    TableLayout tableVerwaltungspersonal = null;
    TableRow head = null;
    private Database database = null;
    private Verwaltungspersonal actual = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verwaltungspersonal);
        database = Database.getInstance(getBaseContext());
        getAllViews();
        initTable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initTable();
    }

    public void initTable() {
        tableVerwaltungspersonal.removeAllViews();
        this.head = new TableRow(this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        head.setLayoutParams(lp);
        TextView colPersonalID = new TextView(this);
        TextView colName = new TextView(this);
        TextView colAbteilung = new TextView(this);
        colPersonalID.setText("Personal_ID");
        colPersonalID.setGravity(Gravity.CENTER_HORIZONTAL);
        colPersonalID.setTextSize(18);
        colPersonalID.setBackgroundResource(column_header);
        colName.setText("Name");
        colName.setGravity(Gravity.CENTER_HORIZONTAL);
        colName.setTextSize(18);
        colName.setBackgroundResource(column_header);
        colAbteilung.setText("Abteilung");
        colAbteilung.setGravity(Gravity.CENTER_HORIZONTAL);
        colAbteilung.setTextSize(18);
        colAbteilung.setBackgroundResource(column_header);
        head.addView(colPersonalID);
        head.addView(colName);
        head.addView(colAbteilung);
        tableVerwaltungspersonal.addView(head);
        try {
            Vector<Verwaltungspersonal> vecVerwaltungspersonal = database.getVerwaltungspersonal();
            for (int i = 0; i < vecVerwaltungspersonal.size(); i++) {
                Verwaltungspersonal verwaltungspersonal = vecVerwaltungspersonal.get(i);
                TableRow row = new TableRow(this);
                TextView txt1 = new TextView(this);
                TextView txt2 = new TextView(this);
                TextView txt3 = new TextView(this);
                txt1.setText(verwaltungspersonal.getPersonal_id() + "");
                txt2.setText(verwaltungspersonal.getName());
                txt3.setText(verwaltungspersonal.getAbteilung() + "");
                txt1.setPadding(7, 1, 7, 1);
                txt2.setPadding(7, 1, 7, 1);
                txt3.setPadding(7, 1, 7, 1);
                txt1.setBackgroundResource(cell_data);
                txt2.setBackgroundResource(cell_data);
                txt3.setBackgroundResource(cell_data);
                row.addView(txt1);
                row.addView(txt2);
                row.addView(txt3);
                row.setId(i);
                row.setClickable(true);
                row.setFocusable(true);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (int i = 1; i < ((TableLayout) v.getParent()).getChildCount(); i++) {
                            TableRow row = (TableRow)((TableLayout) v.getParent()).getChildAt(i);
                            for (int j = 0; j < row.getChildCount(); j++) {
                                row.getChildAt(j).setBackgroundResource(cell_data);
                            }
                        }
                        TableRow row = (TableRow) v;
                        for (int i = 0; i < row.getChildCount(); i++) {
                            row.getChildAt(i).setBackgroundResource(highlight_cell);
                        }
                        TextView txt = (TextView) row.getChildAt(0);
                        TextView txt2 = (TextView) row.getChildAt(1);
                        TextView txt3 = (TextView) row.getChildAt(2);
                        actual = new Verwaltungspersonal(Integer.parseInt(txt.getText().toString()), txt2.getText().toString(),
                                txt3.getText().toString());
                    }
                });
                tableVerwaltungspersonal.addView(row);
            }
        }
        catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void getAllViews() {
        this.btnAdd = (Button) this.findViewById(R.id.btnAdd);
        this.btnUpdate = (Button) this.findViewById(R.id.btnUpdate);
        this.btnDelete = (Button) this.findViewById(R.id.btnDelete);
        this.tableVerwaltungspersonal = (TableLayout) this.findViewById(R.id.tableVerwaltungspersonal);

        this.btnAdd.setOnClickListener(this);
        this.btnUpdate.setOnClickListener(this);
        this.btnDelete.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        try {
            Intent intent = null;
            switch (v.getId()) {
                case R.id.btnAdd:
                    intent = new Intent(this, ActivityAdd.class);
                    intent.putExtra("Caller", "Verwaltungspersonal");
                    startActivity(intent);
                    break;
                case R.id.btnUpdate:
                    intent = new Intent(this, ActivityUpdate.class);
                    intent.putExtra("Caller", actual);
                    startActivity(intent);
                    break;
                case R.id.btnDelete:
                    database.deleteVerwaltungspersonal(actual);
                    initTable();
                    break;
            }
        }
        catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
