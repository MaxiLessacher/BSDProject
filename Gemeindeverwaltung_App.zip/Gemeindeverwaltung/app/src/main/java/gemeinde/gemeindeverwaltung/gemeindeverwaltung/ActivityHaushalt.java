package gemeinde.gemeindeverwaltung.gemeindeverwaltung;

import android.content.Intent;
import android.graphics.Color;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;

import pkgClasses.Haushalt;
import pkgDatabase.Database;

import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.cell_data;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.column_header;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.highlight_cell;

public class ActivityHaushalt extends AppCompatActivity implements View.OnClickListener {
    Button btnAdd = null,
            btnUpdate = null,
            btnDelete = null;
    TableLayout tableHaushalt = null;
    TableRow head = null;
    private Haushalt actual = null;
    private Database database = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_haushalt);
        database = Database.getInstance(getBaseContext());
        getAllViews();
        initTable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initTable();
    }

    public void initTable() {
        tableHaushalt.removeAllViews();
        this.head = new TableRow(this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        head.setLayoutParams(lp);
        TextView col_HHID = new TextView(this);
        TextView colPLZ = new TextView(this);
        TextView colStrasse = new TextView(this);
        TextView colHausnummer = new TextView(this);
        TextView colTuernummer = new TextView(this);
        TextView colWohnflaeche = new TextView(this);
        TextView colLandwirtschaft = new TextView(this);
        TextView colGarten = new TextView(this);
        col_HHID.setText("HH_ID");
        col_HHID.setGravity(Gravity.CENTER_HORIZONTAL);
        col_HHID.setTextSize(18);
        col_HHID.setBackgroundResource(column_header);
        col_HHID.setPadding(7, 1, 7, 1);
        colPLZ.setText("PLZ");
        colPLZ.setGravity(Gravity.CENTER_HORIZONTAL);
        colPLZ.setTextSize(18);
        colPLZ.setBackgroundResource(column_header);
        colPLZ.setPadding(7, 1, 7, 1);
        colStrasse.setText("Strasse");
        colStrasse.setGravity(Gravity.CENTER_HORIZONTAL);
        colStrasse.setTextSize(18);
        colStrasse.setBackgroundResource(column_header);
        colStrasse.setPadding(7, 1, 7, 1);
        colHausnummer.setText("Hausnummer");
        colHausnummer.setGravity(Gravity.CENTER_HORIZONTAL);
        colHausnummer.setTextSize(18);
        colHausnummer.setBackgroundResource(column_header);
        colHausnummer.setPadding(7, 1, 7, 1);
        colTuernummer.setText("Türnummer");
        colTuernummer.setGravity(Gravity.CENTER_HORIZONTAL);
        colTuernummer.setTextSize(18);
        colTuernummer.setBackgroundResource(column_header);
        colTuernummer.setPadding(7, 1, 7, 1);
        colWohnflaeche.setText("Wohnfläche");
        colWohnflaeche.setGravity(Gravity.CENTER_HORIZONTAL);
        colWohnflaeche.setTextSize(18);
        colWohnflaeche.setBackgroundResource(column_header);
        colWohnflaeche.setPadding(7, 1, 7, 1);
        colLandwirtschaft.setText("Landwirtschaft");
        colLandwirtschaft.setGravity(Gravity.CENTER_HORIZONTAL);
        colLandwirtschaft.setTextSize(18);
        colLandwirtschaft.setBackgroundResource(column_header);
        colLandwirtschaft.setPadding(7, 1, 7, 1);
        colGarten.setText("Garten");
        colGarten.setGravity(Gravity.CENTER_HORIZONTAL);
        colGarten.setTextSize(18);
        colGarten.setBackgroundResource(column_header);
        colGarten.setPadding(7, 1, 7, 1);
        head.addView(col_HHID);
        head.addView(colPLZ);
        head.addView(colStrasse);
        head.addView(colHausnummer);
        head.addView(colTuernummer);
        head.addView(colWohnflaeche);
        head.addView(colLandwirtschaft);
        head.addView(colGarten);
        tableHaushalt.addView(head);
        try {
            Vector<Haushalt> vecHaushalt = database.getHaushalte();
            for (int i = 0; i < vecHaushalt.size(); i++) {
                Haushalt haushalt = vecHaushalt.get(i);
                TableRow row = new TableRow(this);
                TextView txt1 = new TextView(this);
                TextView txt2 = new TextView(this);
                TextView txt3 = new TextView(this);
                TextView txt4 = new TextView(this);
                TextView txt5 = new TextView(this);
                TextView txt6 = new TextView(this);
                TextView txt7 = new TextView(this);
                TextView txt8 = new TextView(this);
                txt1.setText(haushalt.getHH_ID()+"");
                txt2.setText(haushalt.getPlz()+"");
                txt3.setText(haushalt.getStrasse()+"");
                txt4.setText(haushalt.getHausnummer()+"");
                txt5.setText(haushalt.getTuernummer()+"");
                txt6.setText(haushalt.getWohnflaeche()+"");
                txt7.setText(haushalt.isLandwirtschaft()+"");
                txt8.setText(haushalt.isGarten() + "");
                txt1.setPadding(7, 1, 7, 1);
                txt2.setPadding(7, 1, 7, 1);
                txt3.setPadding(7, 1, 7, 1);
                txt4.setPadding(7, 1, 7, 1);
                txt5.setPadding(7, 1, 7, 1);
                txt6.setPadding(7, 1, 7, 1);
                txt7.setPadding(7, 1, 7, 1);
                txt8.setPadding(7, 1, 7, 1);
                txt1.setBackgroundResource(cell_data);
                txt2.setBackgroundResource(cell_data);
                txt3.setBackgroundResource(cell_data);
                txt4.setBackgroundResource(cell_data);
                txt5.setBackgroundResource(cell_data);
                txt6.setBackgroundResource(cell_data);
                txt7.setBackgroundResource(cell_data);
                txt8.setBackgroundResource(cell_data);
                row.addView(txt1);
                row.addView(txt2);
                row.addView(txt3);
                row.addView(txt4);
                row.addView(txt5);
                row.addView(txt6);
                row.addView(txt7);
                row.addView(txt8);
                row.setId(i);
                row.setClickable(true);
                row.setFocusable(true);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (int i = 1; i < ((TableLayout) v.getParent()).getChildCount(); i++) {
                            TableRow row = (TableRow) ((TableLayout) v.getParent()).getChildAt(i);
                            for (int j = 0; j < row.getChildCount(); j++) {
                                row.getChildAt(j).setBackgroundResource(cell_data);
                            }
                        }
                        TableRow row = (TableRow) v;
                        for (int i = 0; i < row.getChildCount(); i++) {
                            row.getChildAt(i).setBackgroundResource(highlight_cell);
                        }
                        TextView txt = (TextView) row.getChildAt(0);
                        TextView txt2 = (TextView) row.getChildAt(1);
                        TextView txt3 = (TextView) row.getChildAt(2);
                        TextView txt4 = (TextView) row.getChildAt(3);
                        TextView txt5 = (TextView) row.getChildAt(4);
                        TextView txt6 = (TextView) row.getChildAt(5);
                        TextView txt7 = (TextView) row.getChildAt(6);
                        TextView txt8 = (TextView) row.getChildAt(7);
                        try {
                            actual = new Haushalt(Integer.parseInt(txt.getText().toString()), Integer.parseInt(txt2.getText().toString()),
                                    txt3.getText().toString(), Integer.parseInt(txt4.getText().toString()),
                                    Integer.parseInt(txt5.getText().toString()), Integer.parseInt(txt6.getText().toString()),
                                    Boolean.parseBoolean(txt7.getText().toString()), Boolean.parseBoolean(txt8.getText().toString()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                tableHaushalt.addView(row);
            }
        } catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void getAllViews() {
        this.btnAdd = (Button) this.findViewById(R.id.btnAdd);
        this.btnUpdate = (Button) this.findViewById(R.id.btnUpdate);
        this.btnDelete = (Button) this.findViewById(R.id.btnDelete);
        this.tableHaushalt = (TableLayout) this.findViewById(R.id.tableHaushalt);

        this.btnAdd.setOnClickListener(this);
        this.btnUpdate.setOnClickListener(this);
        this.btnDelete.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        try {
            Intent intent = null;
            switch (v.getId()) {
                case R.id.btnAdd:
                    intent = new Intent(this, ActivityAdd.class);
                    intent.putExtra("Caller", "Haushalt");
                    startActivity(intent);
                    break;
                case R.id.btnUpdate:
                    intent = new Intent(this, ActivityUpdate.class);
                    intent.putExtra("Caller", actual);
                    startActivity(intent);
                    break;
                case R.id.btnDelete:
                    database.deleteHaushalt(actual);
                    initTable();
                    break;
            }
        }
        catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
