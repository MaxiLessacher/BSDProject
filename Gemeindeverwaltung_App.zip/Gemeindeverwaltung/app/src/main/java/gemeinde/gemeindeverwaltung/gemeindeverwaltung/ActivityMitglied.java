package gemeinde.gemeindeverwaltung.gemeindeverwaltung;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;

import pkgClasses.Mitglied;
import pkgDatabase.Database;

import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.cell_data;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.column_header;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.highlight_cell;

public class ActivityMitglied extends AppCompatActivity implements View.OnClickListener {
    Button btnAdd = null,
            btnUpdate = null,
            btnDelete = null;
    TableLayout tableMitglied = null;
    TableRow head = null;
    private Mitglied actual = null;
    private Database database = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mitglied);
        database = Database.getInstance(getBaseContext());
        getAllViews();
        initTable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initTable();
    }

    public void initTable() {
        tableMitglied.removeAllViews();
        this.head = new TableRow(this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        head.setLayoutParams(lp);
        TextView colMitglieds_id = new TextView(this);
        TextView colName = new TextView(this);
        TextView col_HH_ID = new TextView(this);
        TextView colisVorstand = new TextView(this);
        colMitglieds_id.setText("Mitglieds_ID");
        colMitglieds_id.setGravity(Gravity.CENTER_HORIZONTAL);
        colMitglieds_id.setTextSize(18);
        colMitglieds_id.setBackgroundResource(column_header);
        colName.setText("Name");
        colName.setGravity(Gravity.CENTER_HORIZONTAL);
        colName.setTextSize(18);
        colName.setBackgroundResource(column_header);
        col_HH_ID.setText("Vorstand");
        col_HH_ID.setGravity(Gravity.CENTER_HORIZONTAL);
        col_HH_ID.setTextSize(18);
        col_HH_ID.setBackgroundResource(column_header);
        colisVorstand.setText("HH_ID");
        colisVorstand.setGravity(Gravity.CENTER_HORIZONTAL);
        colisVorstand.setTextSize(18);
        colisVorstand.setBackgroundResource(column_header);
        head.addView(colMitglieds_id);
        head.addView(colName);
        head.addView(col_HH_ID);
        head.addView(colisVorstand);
        tableMitglied.addView(head);
        try {
            Vector<Mitglied> vecMitglied = database.getMitglieder();
            for (int i = 0; i < vecMitglied.size(); i++) {
                Mitglied mitglied = vecMitglied.get(i);
                TableRow row = new TableRow(this);
                TextView txt1 = new TextView(this);
                TextView txt2 = new TextView(this);
                TextView txt3 = new TextView(this);
                TextView txt4 = new TextView(this);
                txt1.setText(mitglied.getMitglieds_id()+"");
                txt2.setText(mitglied.getName());
                txt3.setText(mitglied.isHH_Vorstand()+"");
                txt4.setText(mitglied.getHH_ID()+"");
                txt1.setPadding(7, 1, 7, 1);
                txt2.setPadding(7, 1, 7, 1);
                txt3.setPadding(7, 1, 7, 1);
                txt4.setPadding(7, 1, 7, 1);
                txt1.setBackgroundResource(cell_data);
                txt2.setBackgroundResource(cell_data);
                txt3.setBackgroundResource(cell_data);
                txt4.setBackgroundResource(cell_data);
                row.addView(txt1);
                row.addView(txt2);
                row.addView(txt3);
                row.addView(txt4);
                row.setId(i);
                row.setClickable(true);
                row.setFocusable(true);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (int i = 1; i < ((TableLayout) v.getParent()).getChildCount(); i++) {
                            TableRow row = (TableRow)((TableLayout) v.getParent()).getChildAt(i);
                            for (int j = 0; j < row.getChildCount(); j++) {
                                row.getChildAt(j).setBackgroundResource(cell_data);
                            }
                        }
                        TableRow row = (TableRow) v;
                        for (int i = 0; i < row.getChildCount(); i++) {
                            row.getChildAt(i).setBackgroundResource(highlight_cell);
                        }
                        row.setBackgroundColor(Color.parseColor("#E6E6FA"));
                        TextView txt = (TextView) row.getChildAt(0);
                        TextView txt2 = (TextView) row.getChildAt(1);
                        TextView txt3 = (TextView) row.getChildAt(2);
                        TextView txt4 = (TextView) row.getChildAt(3);
                        actual = new Mitglied(Integer.parseInt(txt.getText().toString()),txt2.getText().toString(), Boolean.parseBoolean(txt3.getText().toString()), Integer.parseInt(txt4.getText().toString()));
                    }
                });
                tableMitglied.addView(row);
            }
        } catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void getAllViews() {
        this.btnAdd = (Button) this.findViewById(R.id.btnAdd);
        this.btnUpdate = (Button) this.findViewById(R.id.btnUpdate);
        this.btnDelete = (Button) this.findViewById(R.id.btnDelete);
        this.tableMitglied = (TableLayout) this.findViewById(R.id.tableMitglied);

        this.btnAdd.setOnClickListener(this);
        this.btnUpdate.setOnClickListener(this);
        this.btnDelete.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        try {
            Intent intent = null;
            switch (v.getId()) {
                case R.id.btnAdd:
                    intent = new Intent(this, ActivityAdd.class);
                    intent.putExtra("Caller", "Mitglied");
                    startActivity(intent);
                    break;
                case R.id.btnUpdate:
                    intent = new Intent(this, ActivityUpdate.class);
                    intent.putExtra("Caller", actual);
                    startActivity(intent);
                    break;
                case R.id.btnDelete:
                    database.deleteMitglied(actual);
                    initTable();
                    break;
            }
        }
        catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
