package gemeinde.gemeindeverwaltung.gemeindeverwaltung;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;
import java.util.concurrent.ExecutionException;

import pkgClasses.Ort;
import pkgController.ControllerGetData;
import pkgController.ControllerSendData;
import pkgDatabase.Database;
import pkgEnum.ENUM_SERVICE;

import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.abc_text_cursor_material;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.cell_data;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.column_header;
import static gemeinde.gemeindeverwaltung.gemeindeverwaltung.R.drawable.highlight_cell;

public class ActivityOrt extends AppCompatActivity implements View.OnClickListener {
    Button  btnAdd,
            btnUpdate,
            btnDelete;
    TableLayout tableOrt;
    TableRow head;
    //ControllerGetData controllerGetData = null;
    //ControllerSendData controllerSendData = null;
    Database database = null;
    Ort actual = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ort);
        database = Database.getInstance(getBaseContext());
        actual = new Ort();
        getAllViews();
        initTable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initTable();
    }

    public void initTable() {
        tableOrt.removeAllViews();
        this.head = new TableRow(this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        head.setLayoutParams(lp);
        TextView colPLZ = new TextView(this);
        TextView colOrt = new TextView(this);
        colPLZ.setText("PLZ");
        colPLZ.setGravity(Gravity.CENTER_HORIZONTAL);
        colPLZ.setTextSize(18);
        colPLZ.setBackgroundResource(column_header);
        colOrt.setText("Ort");
        colOrt.setGravity(Gravity.CENTER_HORIZONTAL);
        colOrt.setTextSize(18);
        colOrt.setBackgroundResource(column_header);
        head.addView(colPLZ);
        head.addView(colOrt);
        tableOrt.addView(head);
        try {
            Vector<Ort> vecOrt = database.getOrte();
            for (int i = 0; i < vecOrt.size(); i++) {
                Ort o = vecOrt.get(i);
                TableRow row = new TableRow(this);
                TextView txt1 = new TextView(this);
                TextView txt2 = new TextView(this);
                txt1.setText(o.getPlz()+"");
                txt2.setText(o.getOrt());
                txt1.setPadding(7, 1, 7, 1);
                txt2.setPadding(7, 1, 7, 1);
                txt1.setBackgroundResource(cell_data);
                txt2.setBackgroundResource(cell_data);
                row.addView(txt1);
                row.addView(txt2);
                row.setId(i);
                row.setClickable(true);
                row.setFocusable(true);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (int i = 1; i < ((TableLayout) v.getParent()).getChildCount(); i++) {
                            TableRow row = (TableRow)((TableLayout) v.getParent()).getChildAt(i);
                            for (int j = 0; j < row.getChildCount(); j++) {
                                row.getChildAt(j).setBackgroundResource(cell_data);
                            }
                        }
                        TableRow row = (TableRow) v;
                        for (int i = 0; i < row.getChildCount(); i++) {
                            row.getChildAt(i).setBackgroundResource(highlight_cell);
                        }
                        TextView txt = (TextView) row.getChildAt(0);
                        TextView txt2 = (TextView) row.getChildAt(1);
                        actual = new Ort(Integer.parseInt(txt.getText().toString()), txt2.getText().toString());
                    }
                });
                tableOrt.addView(row);
            }
        } catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void getAllViews() {
        btnAdd = (Button) this.findViewById(R.id.btnAdd);
        btnDelete = (Button) this.findViewById(R.id.btnDelete);
        btnUpdate = (Button) this.findViewById(R.id.btnUpdate);
        this.tableOrt = (TableLayout) this.findViewById(R.id.tableOrt);

        btnAdd.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        try {
            Intent intent = null;
            switch (v.getId()) {
                case R.id.btnAdd:
                    intent = new Intent(this, ActivityAdd.class);
                    intent.putExtra("Caller", "Ort");
                    startActivity(intent);
                    break;
                case R.id.btnUpdate:
                    intent = new Intent(this, ActivityUpdate.class);
                    intent.putExtra("Caller", actual);
                    startActivity(intent);
                    break;
                case R.id.btnDelete:
                    database.deleteOrt(actual);
                    initTable();
                    break;
            }
        }
        catch (Exception e) {
            Toast.makeText(this, "error occured: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
