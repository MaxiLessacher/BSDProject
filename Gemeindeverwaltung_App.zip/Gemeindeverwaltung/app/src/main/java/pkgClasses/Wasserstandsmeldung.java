package pkgClasses;

import java.io.Serializable;
import java.util.Date;
public class Wasserstandsmeldung implements Comparable<Wasserstandsmeldung>, Serializable{
	private String datum;
	private int zaehlerNr;
	private int neuZaehlerstand;

	public Wasserstandsmeldung() {
	}

	public Wasserstandsmeldung(int zaehlerNr, int neuZaehlerstand, String datum) {
		this.datum = datum;
		this.zaehlerNr = zaehlerNr;
		this.neuZaehlerstand = neuZaehlerstand;
	}

	public String getDatum() {
		return datum;
	}

	public void setDatum(String datum) {
		this.datum = datum;
	}

	public int getZaehlerNr() {
		return zaehlerNr;
	}

	public void setZaehlerNr(int zaehlerNr) {
		this.zaehlerNr = zaehlerNr;
	}

	public int getNeuZaehlerstand() {
		return neuZaehlerstand;
	}

	public void setNeuZaehlerstand(int neuZaehlerstand) {
		this.neuZaehlerstand = neuZaehlerstand;
	}

	@Override
	public String toString() {
		return "Wasserstandsmeldung [date=" + datum + ", zaehler_nr="
				+ zaehlerNr + ", neuZaehlerstand=" + neuZaehlerstand + "]";
	}

	@Override
	public int compareTo(Wasserstandsmeldung o) {
		int retValue = 1;
		if (zaehlerNr == o.getZaehlerNr()) {
			retValue = datum.compareTo(o.getDatum());
		}
		return retValue;
	}

}
