package pkgDatabase;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import pkgDatabase.tables.AdressenTable;
import pkgDatabase.tables.HaushalteTable;
import pkgDatabase.tables.MitgliederTable;
import pkgDatabase.tables.OrteTable;
import pkgDatabase.tables.StrassenTable;
import pkgDatabase.tables.VerwaltungspersonalTable;
import pkgDatabase.tables.WasserstandsmeldungenTable;
import pkgDatabase.tables.WasserzaehlerTable;

/**
 * Created by David on 14.03.2016.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "gemeindeverwaltung.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        OrteTable.onCreate(db);
        StrassenTable.onCreate(db);
        AdressenTable.onCreate(db);
        HaushalteTable.onCreate(db);
        MitgliederTable.onCreate(db);
        WasserzaehlerTable.onCreate(db);
        WasserstandsmeldungenTable.onCreate(db);
        VerwaltungspersonalTable.onCreate(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        WasserstandsmeldungenTable.onUpgrade(db, oldVersion, newVersion);
        WasserzaehlerTable.onUpgrade(db, oldVersion, newVersion);
        MitgliederTable.onUpgrade(db, oldVersion, newVersion);
        HaushalteTable.onUpgrade(db, oldVersion, newVersion);
        AdressenTable.onUpgrade(db, oldVersion, newVersion);
        StrassenTable.onUpgrade(db, oldVersion, newVersion);
        OrteTable.onUpgrade(db, oldVersion, newVersion);
        VerwaltungspersonalTable.onUpgrade(db, oldVersion, newVersion);
        onCreate(db);
    }
}
