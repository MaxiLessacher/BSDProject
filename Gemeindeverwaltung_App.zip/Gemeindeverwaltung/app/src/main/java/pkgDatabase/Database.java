package pkgDatabase;

import android.app.Application;
import android.content.Context;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import pkgClasses.Adresse;
import pkgClasses.Haushalt;
import pkgClasses.Mitglied;
import pkgClasses.Ort;
import pkgClasses.Strasse;
import pkgClasses.Verwaltungspersonal;
import pkgClasses.Wasserstandsmeldung;
import pkgClasses.Wasserzaehler;
import pkgDatabase.data.AdressenData;
import pkgDatabase.data.HaushalteData;
import pkgDatabase.data.MitgliederData;
import pkgDatabase.data.OrteData;
import pkgDatabase.data.StrassenData;
import pkgDatabase.data.VerwaltungspersonalData;
import pkgDatabase.data.WasserstandsmeldungenData;
import pkgDatabase.data.WasserzaehlerData;

public class Database extends Application {
	private static Database instance;

	private OrteData od = null;
	private StrassenData sd = null;
	private AdressenData ad = null;
	private HaushalteData hd = null;
	private MitgliederData md = null;
	private WasserzaehlerData wzd = null;
	private WasserstandsmeldungenData wmd = null;
	private VerwaltungspersonalData vd = null;
	   
	public static Database getInstance (Context context) {
	    if (Database.instance == null) {
	    	Database.instance = new Database (context);
	    }
	    return Database.instance;
	}
	
	private Database(Context context) {
		super();
		od = new OrteData(context);
		sd = new StrassenData(context);
		ad = new AdressenData(context);
		hd = new HaushalteData(context);
		md = new MitgliederData(context);
		wzd = new WasserzaehlerData(context);
		wmd = new WasserstandsmeldungenData(context);
		vd = new VerwaltungspersonalData(context);
	}

	public Vector<Ort> getOrte() throws SQLException{
		return od.getAllOrte();
	}
	public Vector<Strasse> getStrassen() throws SQLException {
		return sd.getAllStrassen();
	}
	public Vector<Strasse> getStrassen(int plz) throws SQLException	{
		return sd.getStrassenByPLZ(plz);
	}
	public Vector<Adresse> getAdressen() throws SQLException {
		return ad.getAllAdressen();
	}
	public Vector<Adresse> getAdressen(int plz) throws SQLException {
		return ad.getAdressenByPLZ(plz);
	}
	public Vector<Adresse> getAdressen(int plz, String strasse) throws SQLException {
		return ad.getAdressenByPLZandStrasse(plz,strasse);
	}
	public Vector<Haushalt> getHaushalte() throws SQLException {
		return hd.getAllHaushalte();
	}
	public Vector<Mitglied> getMitglieder() throws SQLException {
		return md.getAllMitglieder();
	}
	public Vector<Verwaltungspersonal> getVerwaltungspersonal() throws SQLException {
		return vd.getAllVerwaltungspersonal();
	}
	public Vector<Wasserzaehler> getWasserzaehler() throws SQLException {
		return wzd.getAllWasserzaehler();
	}
	public Vector<Wasserstandsmeldung> getWasserstandsmeldungen() throws SQLException {
		return wmd.getAllWasserstandsmeldungen();
	}


	public void addOrt(Ort newOrt) throws SQLException {
		if (newOrt!=null) {
			od.createOrt(newOrt);
		}
	}
	public void addStrasse(Strasse newStrasse) throws SQLException {
		if (newStrasse!=null) {
			sd.createStrasse(newStrasse);
		}
	}
	public void addAdresse(Adresse newAdresse) throws SQLException {
		if (newAdresse!=null) {
			ad.createAdresse(newAdresse);
		}
	}
	public void addHaushalt(Haushalt newHaushalt) throws SQLException {
		if (newHaushalt!=null) {
			hd.createHaushalt(newHaushalt);
		}
	}
	public void addMitglied(Mitglied newMitglied) throws SQLException {
		if (newMitglied!=null) {
			md.createMitarbeiter(newMitglied);
		}
	}
	public void addVerwaltungspersonal(Verwaltungspersonal newVw) throws SQLException {
		if (newVw!=null) {
			vd.createVerwaltungspersonal(newVw);
		}
	}
	public void addWasserzaehler(Wasserzaehler newWz) throws SQLException {
		if (newWz!=null) {
			wzd.createWasserzaehler(newWz);
		}
	}
	public void addWasserstandsmeldung(Wasserstandsmeldung newWm) throws SQLException {
		if (newWm!=null) {
			wmd.createWasserstandsmeldung(newWm);
		}
	}
	public void updateOrt(Ort oldOrt,Ort newOrt) throws SQLException {
		if (oldOrt!= null && newOrt != null) {
			od.updateOrt(oldOrt, newOrt);
		}
	}
	public void updateAdresse(Adresse oldAdresse,Adresse newAdresse) throws SQLException {
		if (oldAdresse != null && newAdresse != null) {
			ad.updateAdresse(oldAdresse, newAdresse);
		}
	}
	public void updateHaushalt(Haushalt oldHaushalt,Haushalt newHaushalt) throws SQLException {
		if (oldHaushalt != null && newHaushalt != null) {
			hd.updateHaushalt(oldHaushalt, newHaushalt);
		}
	}
	public void updateMitglied(Mitglied oldMitglied,Mitglied newMitglied) throws SQLException {
		if (oldMitglied != null && newMitglied != null) {
			md.updateMitglied(oldMitglied, newMitglied);
		}
	}
	public void updateStrasse(Strasse oldStrasse,Strasse newStrasse) throws SQLException {
		if (oldStrasse != null && newStrasse != null) {
			sd.updateStrasse(oldStrasse, newStrasse);
		}
	}
	public void updateVerwaltungspersonal(Verwaltungspersonal oldVw,Verwaltungspersonal newVw) throws SQLException {
		if (oldVw != null && newVw != null) {
			vd.updateVerwaltungspersonal(oldVw, newVw);
		}
	}
	public void updateWasserstandsmeldung(Wasserstandsmeldung oldWm,Wasserstandsmeldung newWm) throws SQLException {
		if (oldWm != null && newWm != null) {
			wmd.updateWasserstandsmeldung(oldWm, newWm);
		}
	}
	public void updateWasserzaehler(Wasserzaehler oldWz,Wasserzaehler newWz) throws SQLException {
		if (oldWz != null && newWz != null) {
			wzd.updateWasserzaehler(oldWz,newWz);
		}
	}

	public void deleteOrt(Ort ort) throws SQLException {
		od.deleteOrt(ort);
	}
	public void deleteStrasse(Strasse strasse) throws SQLException {
		sd.deleteStrasse(strasse);
	}
	public void deleteAdresse(Adresse adresse) throws SQLException {
		ad.deleteAdresse(adresse);
	}
	public void deleteHaushalt(Haushalt haushalt) throws SQLException {
		hd.deleteHaushalt(haushalt);
	}
	public void deleteMitglied(Mitglied mitglied) throws SQLException {
		md.deleteMitglied(mitglied);
	}
	public void deleteVerwaltungspersonal(Verwaltungspersonal vw) throws SQLException {
		vd.deleteVerwaltungspersonal(vw);;
	}
	public void deleteWasserzaehler(Wasserzaehler wasserzaehler) throws SQLException {
		wzd.deleteWasserzaehler(wasserzaehler);
	}
	public void deleteWasserstandsmeldung(Wasserstandsmeldung wm) throws SQLException {
		wmd.deleteWasserstandsmeldung(wm);
	}
}