package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 14.03.2016.
 */
public class OrteTable {
    public static final String TABLE_ORT = "orte";
    public static final String COLUMN_PLZ = "plz";
    public static final String COLUMN_ORT = "ort";

    private static final String CREATE_TABLE_ORTE = "create table "
            + TABLE_ORT + "("
            + COLUMN_PLZ + " integer primary key, "
            + COLUMN_ORT + " text not null"
            + ");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_ORTE);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORT);
        onCreate(db);
    }
}
