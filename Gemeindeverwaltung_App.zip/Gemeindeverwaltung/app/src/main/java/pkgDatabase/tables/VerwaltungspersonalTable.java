package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 15.03.2016.
 */
public class VerwaltungspersonalTable {
    public static final String TABLE_VERWALTUNGSPERSONAL = "verwaltungspersonal";
    public static final String COLUMN_PERSONAL_ID = "personalid";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_ABTEILUNG = "abteilung";

    private static final String CREATE_TABLE_VERWALTUNGSPERSONAL = "create table "
            + TABLE_VERWALTUNGSPERSONAL + "("
            + COLUMN_PERSONAL_ID + " integer primary key, "
            + COLUMN_NAME + " text not null, "
            + COLUMN_ABTEILUNG + " text not null"
             +");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_VERWALTUNGSPERSONAL);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VERWALTUNGSPERSONAL);
        onCreate(db);
    }
}
