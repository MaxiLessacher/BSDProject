package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 15.03.2016.
 */
public class HaushalteTable {
    public static final String TABLE_HAUSHALT = "haushalt";
    public static final String COLUMN_STRASSE_FK = "strasse";
    public static final String COLUMN_PLZ_FK = "plz";
    public static final String COLUMN_HAUSNUMMER_FK = "hausnummer";
    public static final String COLUMN_HHID = "hh_id";
    public static final String COLUMN_TUERNR = "tuernr";
    public static final String COLUMN_WOHNFLAECHE = "wohnflaeche";
    public static final String COLUMN_LANDWIRTSCHAFT = "landwirtschaft";
    public static final String COLUMN_GARTEN = "garten";

    private static final String CREATE_TABLE_HAUSHALT = "create table "
            + TABLE_HAUSHALT + "("
            + COLUMN_HHID + " integer primary key, "
            + COLUMN_PLZ_FK + " integer not null, "
            + COLUMN_STRASSE_FK + " text not null, "
            + COLUMN_HAUSNUMMER_FK + " integer not null, "
            + COLUMN_TUERNR + " integer, "
            + COLUMN_WOHNFLAECHE + " integer not null, "
            + COLUMN_LANDWIRTSCHAFT + " number(1) not null, "
            + COLUMN_GARTEN + " number(1) not null, "
            + "FOREIGN KEY(" + COLUMN_PLZ_FK + "," + COLUMN_STRASSE_FK + "," + COLUMN_HAUSNUMMER_FK + ") REFERENCES " + AdressenTable.TABLE_ADRESSE + "(" + AdressenTable.COLUMN_PLZ_FK + "," + AdressenTable.COLUMN_STRASSE_FK + "," + AdressenTable.COLUMN_HAUSNUMMER + ")"
            +");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_HAUSHALT);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HAUSHALT);
        onCreate(db);
    }
}
