package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 15.03.2016.
 */
public class MitgliederTable {
    public static final String TABLE_MITGLIEDER = "mitglieder";
    public static final String COLUMN_MITGLIEDS_ID = "mitglieds_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_HHVORSTAND = "hh_vorstand";
    public static final String COLUMN_HHID_FK = "hh_id";

    private static final String CREATE_TABLE_MITGLIEDER = "create table "
            + TABLE_MITGLIEDER + "("
            + COLUMN_MITGLIEDS_ID + " integer not null, "
            + COLUMN_NAME + " text not null, "
            + COLUMN_HHVORSTAND + " number(1) not null, "
            + COLUMN_HHID_FK + " integer not null, "
            + "FOREIGN KEY(" + COLUMN_HHID_FK + ") REFERENCES " + HaushalteTable.TABLE_HAUSHALT + "(" + HaushalteTable.COLUMN_HHID + "),"
            + "primary key(" + COLUMN_MITGLIEDS_ID + "," + COLUMN_HHID_FK + ")"
            +");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_MITGLIEDER);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MITGLIEDER);
        onCreate(db);
    }
}
