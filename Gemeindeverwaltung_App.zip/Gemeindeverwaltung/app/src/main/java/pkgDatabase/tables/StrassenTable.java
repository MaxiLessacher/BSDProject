package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 14.03.2016.
 */
public class StrassenTable {
    public static final String TABLE_STRASSE = "strassen";
    public static final String COLUMN_STRASSE = "strasse";
    public static final String COLUMN_PLZ_FK = "plz";

    private static final String CREATE_TABLE_STRASSE = "create table "
            + TABLE_STRASSE + "("
            + COLUMN_PLZ_FK + " integer not null, "
            + COLUMN_STRASSE + " text not null, "
            + "FOREIGN KEY(" + COLUMN_PLZ_FK + ") REFERENCES " + OrteTable.TABLE_ORT + "(" + OrteTable.COLUMN_PLZ + "),"
            + "primary key(" + COLUMN_PLZ_FK + "," + COLUMN_STRASSE + ")"
            +");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_STRASSE);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STRASSE);
        onCreate(db);
    }
}
