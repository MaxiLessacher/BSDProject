package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 15.03.2016.
 */
public class WasserzaehlerTable {
    public static final String TABLE_WASSERZAEHLER = "wasserzaehler";
    public static final String COLUMN_ZAEHLERNR = "zaehlernr";
    public static final String COLUMN_HHID_FK = "hh_id";
    public static final String COLUMN_ZAEHLERSTAND = "zaehlerstand";
    public static final String COLUMN_HAUPTZAEHLER = "hauptzaehler";
    public static final String COLUMN_X_KOORDINATE = "x_Koordinate";
    public static final String COLUMN_Y_KOORDINATE = "y_Koordinate";

    private static final String CREATE_TABLE_WASSERZAEHLER = "create table "
            + TABLE_WASSERZAEHLER + "("
            + COLUMN_ZAEHLERNR + " integer not null, "
            + COLUMN_HHID_FK + " integer not null, "
            + COLUMN_ZAEHLERSTAND + " integer not null, "
            + COLUMN_X_KOORDINATE + " integer not null, "
            + COLUMN_Y_KOORDINATE + " integer not null, "
            + COLUMN_HAUPTZAEHLER + " number(1) not null, "
            + "FOREIGN KEY(" + COLUMN_HHID_FK + ") REFERENCES " + HaushalteTable.TABLE_HAUSHALT + "(" + HaushalteTable.COLUMN_HHID + "),"
            + "primary key(" + COLUMN_ZAEHLERNR + ")"
            +");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_WASSERZAEHLER);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WASSERZAEHLER);
        onCreate(db);
    }
}
