package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 15.03.2016.
 */
public class WasserstandsmeldungenTable {
    public static final String TABLE_WASSERSTANDSMELDUNG = "wasserstandsmeldungen";
    public static final String COLUMN_ZAEHLERNR_FK = "zaehlernr";
    public static final String COLUMN_NEU_ZAEHLERSTAND = "neuZaehlerstand";
    public static final String COLUMN_DATUM = "datum";

    private static final String CREATE_TABLE_WASSERSTANDSMELDUNG = "create table "
            + TABLE_WASSERSTANDSMELDUNG + "("
            + COLUMN_ZAEHLERNR_FK + " integer not null, "
            + COLUMN_NEU_ZAEHLERSTAND + " integer not null, "
            + COLUMN_DATUM + " text not null, "
            + "FOREIGN KEY(" + COLUMN_ZAEHLERNR_FK + ") REFERENCES " + WasserzaehlerTable.TABLE_WASSERZAEHLER + "(" + WasserzaehlerTable.COLUMN_ZAEHLERNR + "),"
            + "primary key(" + COLUMN_ZAEHLERNR_FK + "," + COLUMN_DATUM + ")"
            +");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_WASSERSTANDSMELDUNG);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WASSERSTANDSMELDUNG);
        onCreate(db);
    }
}
