package pkgDatabase.tables;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by David on 14.03.2016.
 */
public class AdressenTable {
    public static final String TABLE_ADRESSE = "adressen";
    public static final String COLUMN_STRASSE_FK = "strasse";
    public static final String COLUMN_PLZ_FK = "plz";
    public static final String COLUMN_HAUSNUMMER = "hausnummer";

    private static final String CREATE_TABLE_ADRESSE = "create table "
            + TABLE_ADRESSE + "("
            + COLUMN_PLZ_FK + " integer not null, "
            + COLUMN_STRASSE_FK + " text not null, "
            + COLUMN_HAUSNUMMER + " integer not null, "
            + "FOREIGN KEY(" + COLUMN_PLZ_FK + "," + COLUMN_STRASSE_FK + ") REFERENCES " + StrassenTable.TABLE_STRASSE + "(" + StrassenTable.COLUMN_PLZ_FK + "," + StrassenTable.COLUMN_STRASSE + "),"
            + "primary key(" + COLUMN_PLZ_FK + "," + COLUMN_STRASSE_FK + "," + COLUMN_HAUSNUMMER + ")"
            +");";

    public static void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_ADRESSE);
    }

    public  static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ADRESSE);
        onCreate(db);
    }
}
