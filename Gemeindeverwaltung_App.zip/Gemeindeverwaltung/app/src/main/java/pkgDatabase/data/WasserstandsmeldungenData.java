package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Wasserstandsmeldung;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.WasserstandsmeldungenTable;

/**
 * Created by David on 15.03.2016.
 */
public class WasserstandsmeldungenData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { WasserstandsmeldungenTable.COLUMN_ZAEHLERNR_FK,
            WasserstandsmeldungenTable.COLUMN_NEU_ZAEHLERSTAND,
            WasserstandsmeldungenTable.COLUMN_DATUM
    };
    private Context currentContext = null;

    public WasserstandsmeldungenData(Context context) {
        dbHelper = new DatabaseHelper(context);
        currentContext = context;
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createWasserstandsmeldung(Wasserstandsmeldung wm) throws SQLException {
        ContentValues values = setContentValues(wm);
        open();
        database.insert(
                WasserstandsmeldungenTable.TABLE_WASSERSTANDSMELDUNG,
                null,
                values
        );
        close();
    }

    public void updateWasserstandsmeldung(Wasserstandsmeldung oldWM, Wasserstandsmeldung newWM) throws SQLException {
        ContentValues values = setContentValues(newWM);
        open();
        database.update(
                WasserstandsmeldungenTable.TABLE_WASSERSTANDSMELDUNG,
                values,
                WasserstandsmeldungenTable.COLUMN_ZAEHLERNR_FK + " = ? AND " + WasserstandsmeldungenTable.COLUMN_DATUM + " = ?",
                new String[]{oldWM.getZaehlerNr() + "", oldWM.getDatum() + ""}
        );
        close();
    }

    public void deleteWasserstandsmeldung(Wasserstandsmeldung wm) throws SQLException {
        open();
        database.delete(
                WasserstandsmeldungenTable.TABLE_WASSERSTANDSMELDUNG,
                WasserstandsmeldungenTable.COLUMN_ZAEHLERNR_FK + " = ? AND " + WasserstandsmeldungenTable.COLUMN_DATUM + " = ?",
                new String[]{wm.getZaehlerNr() + "", wm.getDatum() + ""}
        );
        close();
    }

    public Vector<Wasserstandsmeldung> getAllWasserstandsmeldungen() throws SQLException {
        Vector<Wasserstandsmeldung> wms = new Vector<>();
        open();
        Cursor cursor = database.query(
                WasserstandsmeldungenTable.TABLE_WASSERSTANDSMELDUNG,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Wasserstandsmeldung wm = cursorToWasserstandsmeldung(cursor);
            wms.add(wm);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return wms;
    }

    private Wasserstandsmeldung cursorToWasserstandsmeldung(Cursor cursor) {
        Wasserstandsmeldung wm = new Wasserstandsmeldung();
        wm.setZaehlerNr(cursor.getInt(0));
        wm.setNeuZaehlerstand(cursor.getInt(1));
        wm.setDatum(cursor.getString(2));
        return wm;
    }

    private ContentValues setContentValues(Wasserstandsmeldung wm){
        ContentValues cv = new ContentValues();
        cv.put(WasserstandsmeldungenTable.COLUMN_ZAEHLERNR_FK, wm.getZaehlerNr());
        cv.put(WasserstandsmeldungenTable.COLUMN_NEU_ZAEHLERSTAND, wm.getNeuZaehlerstand());
        cv.put(WasserstandsmeldungenTable.COLUMN_DATUM, wm.getDatum());
        return cv;
    }
}
