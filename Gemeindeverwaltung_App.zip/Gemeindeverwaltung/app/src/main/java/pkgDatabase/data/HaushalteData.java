package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Haushalt;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.HaushalteTable;

/**
 * Created by David on 15.03.2016.
 */
public class HaushalteData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { HaushalteTable.COLUMN_HHID,
            HaushalteTable.COLUMN_PLZ_FK,
            HaushalteTable.COLUMN_STRASSE_FK,
            HaushalteTable.COLUMN_HAUSNUMMER_FK,
            HaushalteTable.COLUMN_TUERNR,
            HaushalteTable.COLUMN_WOHNFLAECHE,
            HaushalteTable.COLUMN_LANDWIRTSCHAFT,
            HaushalteTable.COLUMN_GARTEN
    };
    private Context currentContext = null;

    public HaushalteData(Context context) {
        dbHelper = new DatabaseHelper(context);
        currentContext = context;
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createHaushalt(Haushalt haushalt) throws SQLException {
        ContentValues values = setContentValues(haushalt);
        open();
        database.insert(
                HaushalteTable.TABLE_HAUSHALT,
                null,
                values
        );
        close();
    }

    public void updateHaushalt(Haushalt oldHaushalt, Haushalt newHaushalt) throws SQLException {
        ContentValues values = setContentValues(newHaushalt);
        open();
        database.update(
                HaushalteTable.TABLE_HAUSHALT,
                values,
                HaushalteTable.COLUMN_HHID + " = ?",
                new String[]{oldHaushalt.getHH_ID() + ""}
        );
        close();
    }

    public void deleteHaushalt(Haushalt haushalt) throws SQLException {
        open();
        database.delete(
                HaushalteTable.TABLE_HAUSHALT,
                HaushalteTable.COLUMN_HHID + " = ?",
                new String[]{haushalt.getHH_ID() + ""}
        );
        close();
    }

    public Vector<Haushalt> getAllHaushalte() throws SQLException {
        Vector<Haushalt> haushalte = new Vector<>();
        open();
        Cursor cursor = database.query(
                HaushalteTable.TABLE_HAUSHALT,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Haushalt haushalt = cursorToHaushalt(cursor);
            haushalte.add(haushalt);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return haushalte;
    }

    private Haushalt cursorToHaushalt(Cursor cursor) {
        Haushalt haushalt = new Haushalt();
        haushalt.setHH_ID(cursor.getInt(0));
        haushalt.setPlz(cursor.getInt(1));
        haushalt.setStrasse(cursor.getString(2));
        haushalt.setHausnummer(cursor.getInt(3));
        haushalt.setTuernummer(cursor.getInt(4));
        haushalt.setWohnflaeche(cursor.getInt(5));
        boolean landwirtschaft = false;
        boolean garten = false;
        if (cursor.getInt(6) == 1) {
            landwirtschaft = true;
        }
        if (cursor.getInt(7) == 1) {
            garten = true;
        }
        haushalt.setLandwirtschaft(landwirtschaft);
        haushalt.setGarten(garten);
        return haushalt;
    }

    private ContentValues setContentValues(Haushalt haushalt){
        ContentValues cv = new ContentValues();
        cv.put(HaushalteTable.COLUMN_HHID, haushalt.getHH_ID());
        cv.put(HaushalteTable.COLUMN_PLZ_FK, haushalt.getPlz());
        cv.put(HaushalteTable.COLUMN_STRASSE_FK, haushalt.getStrasse());
        cv.put(HaushalteTable.COLUMN_HAUSNUMMER_FK, haushalt.getHausnummer());
        cv.put(HaushalteTable.COLUMN_TUERNR, haushalt.getTuernummer());
        cv.put(HaushalteTable.COLUMN_WOHNFLAECHE, haushalt.getWohnflaeche());
        int garten = 0;
        int landwirtschaft = 0;
        if (haushalt.isGarten()) {
            garten = 1;
        }
        if (haushalt.isLandwirtschaft()) {
            landwirtschaft = 1;
        }
        cv.put(HaushalteTable.COLUMN_LANDWIRTSCHAFT, landwirtschaft);
        cv.put(HaushalteTable.COLUMN_GARTEN, garten);
        return cv;
    }
}
