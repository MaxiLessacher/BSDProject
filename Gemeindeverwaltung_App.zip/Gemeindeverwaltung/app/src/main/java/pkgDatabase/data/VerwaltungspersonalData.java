package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Verwaltungspersonal;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.VerwaltungspersonalTable;

/**
 * Created by David on 15.03.2016.
 */
public class VerwaltungspersonalData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { VerwaltungspersonalTable.COLUMN_PERSONAL_ID,
            VerwaltungspersonalTable.COLUMN_NAME,
            VerwaltungspersonalTable.COLUMN_ABTEILUNG
    };
    private Context currentContext = null;

    public VerwaltungspersonalData(Context context) {
        dbHelper = new DatabaseHelper(context);
        currentContext = context;
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createVerwaltungspersonal(Verwaltungspersonal vp) throws SQLException {
        ContentValues values = setContentValues(vp);
        open();
        database.insert(
                VerwaltungspersonalTable.TABLE_VERWALTUNGSPERSONAL,
                null,
                values
        );
        close();
    }

    public void updateVerwaltungspersonal(Verwaltungspersonal oldVp, Verwaltungspersonal newVp) throws SQLException {
        ContentValues values = setContentValues(newVp);
        open();
        database.update(
                VerwaltungspersonalTable.TABLE_VERWALTUNGSPERSONAL,
                values,
                VerwaltungspersonalTable.COLUMN_PERSONAL_ID + " = ?",
                new String[]{oldVp.getPersonal_id() + ""}
        );
        close();
    }

    public void deleteVerwaltungspersonal(Verwaltungspersonal vp) throws SQLException {
        open();
        database.delete(
                VerwaltungspersonalTable.TABLE_VERWALTUNGSPERSONAL,
                VerwaltungspersonalTable.COLUMN_PERSONAL_ID + " = ?",
                new String[]{vp.getPersonal_id()+""}
        );
        close();
    }

    public Vector<Verwaltungspersonal> getAllVerwaltungspersonal() throws SQLException {
        Vector<Verwaltungspersonal> vps = new Vector<>();
        open();
        Cursor cursor = database.query(
                VerwaltungspersonalTable.TABLE_VERWALTUNGSPERSONAL,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Verwaltungspersonal vp = cursorToVerwaltungspersonal(cursor);
            vps.add(vp);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return vps;
    }

    private Verwaltungspersonal cursorToVerwaltungspersonal(Cursor cursor) {
        Verwaltungspersonal vp = new Verwaltungspersonal();
        vp.setPersonal_id(cursor.getInt(0));
        vp.setName(cursor.getString(1));
        vp.setAbteilung(cursor.getString(2));
        return vp;
    }

    private ContentValues setContentValues(Verwaltungspersonal vp){
        ContentValues cv = new ContentValues();
        cv.put(VerwaltungspersonalTable.COLUMN_PERSONAL_ID, vp.getPersonal_id());
        cv.put(VerwaltungspersonalTable.COLUMN_NAME, vp.getName());
        cv.put(VerwaltungspersonalTable.COLUMN_ABTEILUNG, vp.getAbteilung());
        return cv;
    }
}
