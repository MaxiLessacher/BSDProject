package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Strasse;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.StrassenTable;

/**
 * Created by David on 15.03.2016.
 */
public class StrassenData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { StrassenTable.COLUMN_PLZ_FK,
            StrassenTable.COLUMN_STRASSE
    };
    private Context currentContext = null;

    public StrassenData(Context context) {
        dbHelper = new DatabaseHelper(context);
        currentContext = context;
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createStrasse(Strasse strasse) throws SQLException {
        ContentValues values = setContentValues(strasse);
        open();
        database.insert(
                StrassenTable.TABLE_STRASSE,
                null,
                values
        );
        close();
    }

    public void updateStrasse(Strasse oldStrasse, Strasse newStrasse) throws SQLException {
        ContentValues values = setContentValues(newStrasse);
        open();
        database.update(
                StrassenTable.TABLE_STRASSE,
                values,
                StrassenTable.COLUMN_PLZ_FK + " = ? AND " + StrassenTable.COLUMN_STRASSE + " = ?",
                new String[]{oldStrasse.getPlz() + "", oldStrasse.getStrasse() + ""}
        );
        close();
    }

    public void deleteStrasse(Strasse strasse) throws SQLException {
        open();
        database.delete(
                StrassenTable.TABLE_STRASSE,
                StrassenTable.COLUMN_PLZ_FK + " = ? AND " + StrassenTable.COLUMN_STRASSE + " = ?",
                new String[]{strasse.getPlz() + "", strasse.getStrasse() + ""}
        );
        close();
    }

    public Vector<Strasse> getStrassenByPLZ(int plz) throws SQLException {
        Vector<Strasse> strasses = new Vector<>();
        open();
        Cursor cursor = database.query(
                StrassenTable.TABLE_STRASSE,
                allColumns,
                StrassenTable.COLUMN_PLZ_FK + " = ?",
                new String[]{plz+""},
                null,
                null,
                null
        );
        cursor.moveToFirst();
        while(!cursor.isAfterLast()) {
            Strasse strasse = cursorToStrasse(cursor);
            strasses.add(strasse);
            cursor.moveToNext();
        }
        cursor.close();
        close();
        return strasses;
    }
    public Vector<Strasse> getAllStrassen() throws SQLException {
        Vector<Strasse> strassen = new Vector<>();
        open();
        Cursor cursor = database.query(
                StrassenTable.TABLE_STRASSE,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Strasse strasse = cursorToStrasse(cursor);
            strassen.add(strasse);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return strassen;
    }

    private Strasse cursorToStrasse(Cursor cursor) {
        Strasse strasse = new Strasse();
        strasse.setPlz(cursor.getInt(0));
        strasse.setStrasse(cursor.getString(1));
        return strasse;
    }

    private ContentValues setContentValues(Strasse strasse){
        ContentValues cv = new ContentValues();
        cv.put(StrassenTable.COLUMN_PLZ_FK, strasse.getPlz());
        cv.put(StrassenTable.COLUMN_STRASSE, strasse.getStrasse());
        return cv;
    }
}
