package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Ort;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.OrteTable;

/**
 * Created by David on 15.03.2016.
 */
public class OrteData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { OrteTable.COLUMN_PLZ,
            OrteTable.COLUMN_ORT };

    public OrteData(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
        database.close();
    }

    public void createOrt(Ort ort) throws SQLException {
        open();
        ContentValues values = new ContentValues();
        values.put(OrteTable.COLUMN_PLZ, ort.getPlz());
        values.put(OrteTable.COLUMN_ORT, ort.getOrt());
        database.insert(
                OrteTable.TABLE_ORT,
                null,
                values
        );
        close();
    }

    public void updateOrt(Ort oldOrt, Ort newOrt) throws SQLException {
        ContentValues values = new ContentValues();
        values.put(OrteTable.COLUMN_PLZ, newOrt.getPlz());
        values.put(OrteTable.COLUMN_ORT, newOrt.getOrt());
        open();
        database.update(
                OrteTable.TABLE_ORT,
                values,
                OrteTable.COLUMN_PLZ + " = ?",
                new String[]{oldOrt.getPlz()+""}
        );
        close();
    }

    public Ort getOrtByPLZ(int plz) throws SQLException {
        open();
        Cursor cursor = database.query(
                OrteTable.TABLE_ORT,
                allColumns,
                OrteTable.COLUMN_PLZ + " = ?",
                new String[]{plz+""},
                null,
                null,
                null
        );
        cursor.moveToFirst();
        Ort ort = cursorToOrt(cursor);
        cursor.close();
        close();
        return ort;
    }

    public void deleteOrt(Ort ort) throws SQLException {
        open();
        database.delete(
                OrteTable.TABLE_ORT,
                OrteTable.COLUMN_PLZ + " = ?",
                new String[]{ort.getPlz() + ""}
        );
        close();
    }

    public Vector<Ort> getAllOrte() throws SQLException{
        Vector<Ort> orte = new Vector<>();
        open();
        Cursor cursor = database.query(
                OrteTable.TABLE_ORT,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Ort ort = cursorToOrt(cursor);
            orte.add(ort);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return orte;
    }

    private Ort cursorToOrt(Cursor cursor) {
        Ort ort = new Ort();
        ort.setPlz(cursor.getInt(0));
        ort.setOrt(cursor.getString(1));
        return ort;
    }
}
