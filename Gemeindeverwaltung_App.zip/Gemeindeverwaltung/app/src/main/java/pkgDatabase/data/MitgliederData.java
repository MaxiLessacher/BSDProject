package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Mitglied;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.MitgliederTable;

/**
 * Created by David on 15.03.2016.
 */
public class MitgliederData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { MitgliederTable.COLUMN_MITGLIEDS_ID,
            MitgliederTable.COLUMN_NAME,
            MitgliederTable.COLUMN_HHVORSTAND,
            MitgliederTable.COLUMN_HHID_FK
    };
    private Context currentContext = null;

    public MitgliederData(Context context) {
        dbHelper = new DatabaseHelper(context);
        currentContext = context;
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createMitarbeiter(Mitglied mitglied) throws SQLException {
        ContentValues values = setContentValues(mitglied);
        open();
        database.insert(
                MitgliederTable.TABLE_MITGLIEDER,
                null,
                values
        );
        close();
    }

    public void updateMitglied(Mitglied oldMitglied, Mitglied newMitglied) throws SQLException {
        ContentValues values = setContentValues(newMitglied);
        open();
        database.update(
                MitgliederTable.TABLE_MITGLIEDER,
                values,
                MitgliederTable.COLUMN_MITGLIEDS_ID + " = ? AND " + MitgliederTable.COLUMN_HHID_FK + " = ?",
                new String[]{oldMitglied.getMitglieds_id() + "", oldMitglied.getHH_ID() + ""}
        );
        close();
    }

    public void deleteMitglied(Mitglied mitglied) throws SQLException {
        open();
        database.delete(
                MitgliederTable.TABLE_MITGLIEDER,
                MitgliederTable.COLUMN_MITGLIEDS_ID + " = ? AND " + MitgliederTable.COLUMN_HHID_FK + " = ?",
                new String[]{mitglied.getMitglieds_id() + "", mitglied.getHH_ID() + ""}
        );
        close();
    }

    public Vector<Mitglied> getAllMitglieder() throws SQLException {
        Vector<Mitglied> mitglieder = new Vector<>();
        open();
        Cursor cursor = database.query(
                MitgliederTable.TABLE_MITGLIEDER,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Mitglied mitglied = cursorToMitglied(cursor);
            mitglieder.add(mitglied);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return mitglieder;
    }

    private Mitglied cursorToMitglied(Cursor cursor) {
        Mitglied mitglied = new Mitglied();
        mitglied.setMitglieds_id(cursor.getInt(0));
        mitglied.setName(cursor.getString(1));
        boolean hh_vorstand = false;
        if (cursor.getInt(2) == 1) {
            hh_vorstand = true;
        }
        mitglied.setHH_Vorstand(hh_vorstand);
        mitglied.setHH_ID(cursor.getInt(3));
        return mitglied;
    }

    private ContentValues setContentValues(Mitglied mitglied){
        ContentValues cv = new ContentValues();
        cv.put(MitgliederTable.COLUMN_MITGLIEDS_ID, mitglied.getMitglieds_id());
        cv.put(MitgliederTable.COLUMN_NAME, mitglied.getName());
        int hh_vorstand = 0;
        if (mitglied.isHH_Vorstand()) {
            hh_vorstand = 1;
        }
        cv.put(MitgliederTable.COLUMN_HHVORSTAND, hh_vorstand);
        cv.put(MitgliederTable.COLUMN_HHID_FK, mitglied.getHH_ID());
        return cv;
    }
}
