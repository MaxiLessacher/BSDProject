package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Adresse;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.AdressenTable;

/**
 * Created by David on 15.03.2016.
 */
public class AdressenData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { AdressenTable.COLUMN_PLZ_FK,
            AdressenTable.COLUMN_STRASSE_FK,
            AdressenTable.COLUMN_HAUSNUMMER
    };
    private Context currentContext = null;

    public AdressenData(Context context) {
        dbHelper = new DatabaseHelper(context);
        currentContext = context;
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createAdresse(Adresse adresse) throws SQLException {
        ContentValues values = setContentValues(adresse);
        open();
        database.insert(
                AdressenTable.TABLE_ADRESSE,
                null,
                values
        );
        close();
    }

    public void updateAdresse(Adresse oldAdresse, Adresse newAdresse) throws SQLException {
        ContentValues values = setContentValues(newAdresse);
        open();
        database.update(
                AdressenTable.TABLE_ADRESSE,
                values,
                AdressenTable.COLUMN_PLZ_FK + " = ? AND " + AdressenTable.COLUMN_STRASSE_FK + " = ? AND " + AdressenTable.COLUMN_HAUSNUMMER + " = ?",
                new String[]{oldAdresse.getPlz() + "", oldAdresse.getStrasse() + "", oldAdresse.getHausnummer() + ""}
        );
        close();
    }

    public void deleteAdresse(Adresse adresse) throws SQLException {
        open();
        database.delete(
                AdressenTable.TABLE_ADRESSE,
                AdressenTable.COLUMN_PLZ_FK + " = ? AND " + AdressenTable.COLUMN_STRASSE_FK + " = ? AND " + AdressenTable.COLUMN_HAUSNUMMER + " = ?",
                new String[]{adresse.getPlz() + "", adresse.getStrasse() + "", adresse.getHausnummer() + ""}
        );
        close();
    }

    public Vector<Adresse> getAdressenByPLZandStrasse(int plz, String strasse) throws SQLException {
        Vector<Adresse> adresses = new Vector<>();
        open();
        Cursor cursor = database.query(
                AdressenTable.TABLE_ADRESSE,
                allColumns,
                AdressenTable.COLUMN_PLZ_FK + " = ? AND " + AdressenTable.COLUMN_STRASSE_FK + " = ?",
                new String[]{plz+"", strasse},
                null,
                null,
                null
        );
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Adresse adresse = cursorToAdresse(cursor);
            adresses.add(adresse);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return adresses;
    }

    public Vector<Adresse> getAdressenByPLZ(int plz) throws SQLException {
        Vector<Adresse> adresses = new Vector<>();
        open();
        Cursor cursor = database.query(
                AdressenTable.TABLE_ADRESSE,
                allColumns,
                AdressenTable.COLUMN_PLZ_FK + " = ?",
                new String[]{plz+""},
                null,
                null,
                null
        );
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Adresse adresse = cursorToAdresse(cursor);
            adresses.add(adresse);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return adresses;
    }

    public Vector<Adresse> getAllAdressen() throws SQLException {
        Vector<Adresse> adressen = new Vector<>();
        open();
        Cursor cursor = database.query(
                AdressenTable.TABLE_ADRESSE,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Adresse adresse = cursorToAdresse(cursor);
            adressen.add(adresse);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return adressen;
    }

    private Adresse cursorToAdresse(Cursor cursor) {
        Adresse adresse = new Adresse();
        adresse.setPlz(cursor.getInt(0));
        adresse.setStrasse(cursor.getString(1));
        adresse.setHausnummer(cursor.getInt(2));
        return adresse;
    }

    private ContentValues setContentValues(Adresse adresse){
        ContentValues cv = new ContentValues();
        cv.put(AdressenTable.COLUMN_PLZ_FK, adresse.getPlz());
        cv.put(AdressenTable.COLUMN_STRASSE_FK, adresse.getStrasse());
        cv.put(AdressenTable.COLUMN_HAUSNUMMER, adresse.getHausnummer());
        return cv;
    }
}
