package pkgDatabase.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.Vector;

import pkgClasses.Wasserzaehler;
import pkgDatabase.DatabaseHelper;
import pkgDatabase.tables.WasserzaehlerTable;

/**
 * Created by David on 15.03.2016.
 */
public class WasserzaehlerData {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    private String[] allColumns = { WasserzaehlerTable.COLUMN_ZAEHLERNR,
            WasserzaehlerTable.COLUMN_HHID_FK,
            WasserzaehlerTable.COLUMN_ZAEHLERSTAND,
            WasserzaehlerTable.COLUMN_X_KOORDINATE,
            WasserzaehlerTable.COLUMN_Y_KOORDINATE,
            WasserzaehlerTable.COLUMN_HAUPTZAEHLER
    };
    private Context currentContext = null;

    public WasserzaehlerData(Context context) {
        dbHelper = new DatabaseHelper(context);
        currentContext = context;
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createWasserzaehler(Wasserzaehler wasserzaehler) throws SQLException {
        ContentValues values = setContentValues(wasserzaehler);
        open();
        database.insert(
                WasserzaehlerTable.TABLE_WASSERZAEHLER,
                null,
                values
        );
        close();
    }

    public void updateWasserzaehler(Wasserzaehler oldWz, Wasserzaehler newWz) throws SQLException {
        ContentValues values = setContentValues(newWz);
        open();
        database.update(
                WasserzaehlerTable.TABLE_WASSERZAEHLER,
                values,
                WasserzaehlerTable.COLUMN_ZAEHLERNR + " = ?",
                new String[]{oldWz.getZaehler_nr() + ""}
        );
        close();
    }

    public void deleteWasserzaehler(Wasserzaehler wz) throws SQLException {
        open();
        database.delete(
                WasserzaehlerTable.TABLE_WASSERZAEHLER,
                WasserzaehlerTable.COLUMN_ZAEHLERNR + " = ?",
                new String[]{wz.getZaehler_nr() + ""}
        );
        close();
    }

    public Vector<Wasserzaehler> getAllWasserzaehler() throws SQLException {
        Vector<Wasserzaehler> wasserzaehlers = new Vector<>();
        open();
        Cursor cursor = database.query(
                WasserzaehlerTable.TABLE_WASSERZAEHLER,
                allColumns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Wasserzaehler wz = cursorToWasserzaehler(cursor);
            wasserzaehlers.add(wz);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        close();
        return wasserzaehlers;
    }

    private Wasserzaehler cursorToWasserzaehler(Cursor cursor) {
        Wasserzaehler wasserzaehler = new Wasserzaehler();
        wasserzaehler.setZaehler_nr(cursor.getInt(0));
        wasserzaehler.setHH_ID(cursor.getInt(1));
        wasserzaehler.setZaehlerstand(cursor.getInt(2));
        wasserzaehler.setStandort_x(cursor.getInt(3));
        wasserzaehler.setStandort_y(cursor.getInt(4));
        boolean hauptzaehler = false;
        if (cursor.getInt(5) == 1) {
            hauptzaehler = true;
        }
        wasserzaehler.setHauptzaehler(hauptzaehler);
        return wasserzaehler;
    }

    private ContentValues setContentValues(Wasserzaehler wasserzaehler){
        ContentValues cv = new ContentValues();
        cv.put(WasserzaehlerTable.COLUMN_ZAEHLERNR, wasserzaehler.getZaehler_nr());
        cv.put(WasserzaehlerTable.COLUMN_HHID_FK, wasserzaehler.getHH_ID());
        cv.put(WasserzaehlerTable.COLUMN_ZAEHLERSTAND, wasserzaehler.getZaehlerstand());
        cv.put(WasserzaehlerTable.COLUMN_X_KOORDINATE, wasserzaehler.getStandort_x());
        cv.put(WasserzaehlerTable.COLUMN_Y_KOORDINATE, wasserzaehler.getStandort_y());
        int hauptzaehler = 0;
        if (wasserzaehler.isHauptzaehler()) {
            hauptzaehler = 1;
        }
        cv.put(WasserzaehlerTable.COLUMN_HAUPTZAEHLER, hauptzaehler);
        return cv;
    }
}
