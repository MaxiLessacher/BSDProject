﻿using Microsoft.Maps.MapControl.WPF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BingMapsTestProgramm
{
    class MyPushpin : Pushpin
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
