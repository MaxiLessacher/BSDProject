﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BingMapsTestProgramm
{
    class Database
    {
        private OleDbConnection connection = null;
        private OleDbTransaction transe = null;
        private String connStr = "";
        public List<Haushalt> Haushalte = new List<Haushalt>();
        public List<Mitglied> Mitglieder = new List<Mitglied>();

        public Database(String ip)
        {
            connStr = "Provider=OraOLEDB.Oracle; Data Source=" + ip +"/ora11g; User Id=d5b30; Password=d5b30;OLEDB.NET=True;";
            //connStr = "Provider=OraOLEDB.Oracle; Data Source=192.168.128.151/ora11g;User Id=d5b30;Password =d5b30; OLEDB.NET=True;";
        }

        public void getDatafromDatabase()
        {
            connect();
            var reader = new OleDbCommand("Select h.hh_id, h.name, h.plz, h.nummer, h.tuernr, h.wohnflaeche, h.landwirtschaft, h.garten, o.name from haushalt h inner join adresse ad on h.plz = ad.plz and h.nummer = ad.nummer and h.name = ad.name join strasse st on st.plz = ad.plz and st.name = ad.name join ort o on o.plz = st.plz", this.connection).ExecuteReader();
            while (reader.Read())
            {
                int id = Convert.ToInt32(reader["hh_id"].ToString());
                String name = Convert.ToString(reader["Name"].ToString());
                int plz = Convert.ToInt32(reader["plz"].ToString());
                int tuernr = Convert.ToInt32(reader["tuernr"].ToString());
                int number = Convert.ToInt32(reader["nummer"].ToString());
                int wohnflaeche = Convert.ToInt32(reader["wohnflaeche"].ToString());
                int landwirtschaft = Convert.ToInt32(reader["landwirtschaft"].ToString());
                int garten = Convert.ToInt32(reader["garten"].ToString());
                String ort = reader[8].ToString();
                Boolean landWirtschaftBool = false;
                Boolean gartenBool = false;
                if (landwirtschaft == 1)
                {
                    landWirtschaftBool = true;
                }
                if (garten == 1)
                {
                    gartenBool = true;
                }
                Haushalte.Add(new Haushalt(id, name, plz, number, tuernr, wohnflaeche, landWirtschaftBool, gartenBool, ort));
            }

            reader = new OleDbCommand("SELECT mitglieds_id, name, hh_vorstand, hh_id FROM mitglieder", this.connection).ExecuteReader();
            while (reader.Read())
            {
                int mit = Convert.ToInt32(reader["mitglieds_id"]);
                String name = reader["name"].ToString();
                int hhv = Convert.ToInt32(reader["hh_vorstand"]);
                int hhi = Convert.ToInt32(reader["hh_id"]);
                Boolean hh_v = false;
                if (hhv == 1) hh_v = true;
                Mitglieder.Add(new Mitglied(mit, name, hh_v, hhi));
            }
            connection.Close();
        }

        public OleDbConnection Connection
        {
            get
            {
                return connection;
            }

            set
            {
                connection = value;
            }
        }

        

        //try to open a connection to oracle
        public void connect()
        {
            connection = new OleDbConnection(connStr);
            connection.Open();

        }

        public void startTranse()
        {
            if (this.transe != null)
            {
                transe.Rollback();
            }
            this.transe = connection.BeginTransaction();
        }

        private void execNQ(string sql)
        {
            new OleDbCommand(sql, this.Connection, this.transe)
                .ExecuteNonQuery();
        }

        public void Commit()
        {
            new OleDbCommand("COMMIT", this.Connection, this.transe)
                .ExecuteNonQuery();
        }

        public void Rollback()
        {
            this.execNQ("ROLLBACK");
        }


        //close the connection
        public void close()
        {
            connection.Close();
        }
    }
}
