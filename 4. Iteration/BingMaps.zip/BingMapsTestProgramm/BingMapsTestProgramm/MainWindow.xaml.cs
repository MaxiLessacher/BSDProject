﻿using Microsoft.Maps.MapControl.WPF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace BingMapsTestProgramm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static String BingMapsKey = "AkJ_UmdQzAxJcjzFYFeQa1FMQkqMsXf1kJyyaB_G5DKA8V19Yhurafpl1t-I8HmZ";
        private Database db;

        public MainWindow()
        {
            InitializeComponent();
        }

        public XmlDocument Geocode(string addressQuery)
        {
            //Create REST Services geocode request using Locations API
            string geocodeRequest = "http://dev.virtualearth.net/REST/v1/Locations/" + addressQuery + "?o=xml&key=" + BingMapsKey;

            //Make the request and get the response
            XmlDocument geocodeResponse = GetXmlResponse(geocodeRequest);

            return (geocodeResponse);
        }

        private XmlDocument GetXmlResponse(string requestUrl)
        {
            System.Diagnostics.Trace.WriteLine("Request URL (XML): " + requestUrl);
            HttpWebRequest request = WebRequest.Create(requestUrl) as HttpWebRequest;
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                if (response.StatusCode != HttpStatusCode.OK)
                    throw new Exception(String.Format("Server error (HTTP {0}: {1}).",
                    response.StatusCode,
                    response.StatusDescription));
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(response.GetResponseStream());
                return xmlDoc;
            }
        }

        private void FindDisplay(XmlDocument xmlDoc, String forPushpin, Haushalt haushalt)
        {
            //Create namespace manager
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("rest", "http://schemas.microsoft.com/search/local/ws/rest/v1");

            //Get all geocode locations in the response 
            XmlNodeList locationElements = xmlDoc.SelectNodes("//rest:Location", nsmgr);
            if (locationElements.Count != 0)
            {
                //Get the geocode location points that are used for display (UsageType=Display)
                XmlNodeList displayGeocodePoints =
                        locationElements[0].SelectNodes(".//rest:GeocodePoint/rest:UsageType[.='Display']/parent::node()", nsmgr);
                string latitude = displayGeocodePoints[0].SelectSingleNode(".//rest:Latitude", nsmgr).InnerText;
                string longitude = displayGeocodePoints[0].SelectSingleNode(".//rest:Longitude", nsmgr).InnerText;
                Console.WriteLine(latitude + " " + longitude);
                //Center the map at the geocoded location and display the results
                Location location = new Location(convertStringDouble(latitude), convertStringDouble(longitude));
                
                //myMap.Center = location;
                //Console.WriteLine(location + " " + myMap.Center);
                //myMap.ZoomLevel = 12;

                MapLayer myMapLayer = new MapLayer();
                myMap.Children.Add(myMapLayer);
                
                for (int j = 0; j < db.Mitglieder.Count; j++)
                {
                    if (db.Mitglieder.ElementAt(j).h_id == haushalt.hid)
                    {
                        forPushpin += "\nHaushaltsvorstand: " + db.Mitglieder.ElementAt(j).name;
                    }
                }

                MyPushpin pushpin = new MyPushpin();
                ToolTipService.SetToolTip(pushpin, forPushpin);
                pushpin.Location = location;
                myMapLayer.Children.Add(pushpin);

            }
        }

        private double convertStringDouble(string toConvert)
        {
            double testNum = 0.5;
            char decimalSepparator;
            decimalSepparator = testNum.ToString()[1];

            return double.Parse(toConvert.Replace('.', decimalSepparator).Replace(',', decimalSepparator));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            myMap.Children.Clear();
            XmlDocument searchResponse = Geocode(searchText.Text);
            ZoomInMap(searchResponse);
            fillMap();
        }

        private void ZoomInMap(XmlDocument xmlDoc)
        {

            //Create namespace manager
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("rest", "http://schemas.microsoft.com/search/local/ws/rest/v1");

            //Get all geocode locations in the response 
            XmlNodeList locationElements = xmlDoc.SelectNodes("//rest:Location", nsmgr);
            if (locationElements.Count != 0)
            {
                //Get the geocode location points that are used for display (UsageType=Display)
                XmlNodeList displayGeocodePoints =
                        locationElements[0].SelectNodes(".//rest:GeocodePoint/rest:UsageType[.='Display']/parent::node()", nsmgr);
                string latitude = displayGeocodePoints[0].SelectSingleNode(".//rest:Latitude", nsmgr).InnerText;
                string longitude = displayGeocodePoints[0].SelectSingleNode(".//rest:Longitude", nsmgr).InnerText;
                Console.WriteLine(latitude + " " + longitude);
                //Center the map at the geocoded location and display the results
                Location location = new Location(convertStringDouble(latitude), convertStringDouble(longitude));

                myMap.Center = location;
                //Console.WriteLine(location + " " + myMap.Center);
                myMap.ZoomLevel = 12;
            }
        }

        private void fillMap()
        {
            XmlDocument search = Geocode("Villach");
            String searchstring = null;
            for (int i = 0; i < db.Haushalte.Count; i++)
            {
                searchstring = db.Haushalte.ElementAt(i).name + " " + db.Haushalte.ElementAt(i).number + ", " + db.Haushalte.ElementAt(i).plz + " " + db.Haushalte.ElementAt(i).ort;
                Console.WriteLine(searchstring);
                search = Geocode(searchstring);
                FindDisplay(search, searchstring, db.Haushalte.ElementAt(i));
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            db = new Database(ip.Text);
            db.getDatafromDatabase();
            myMap.Focus();
            fillMap();
            searchText.IsEnabled = true;
            btnConnect.IsEnabled = false;
            btnSearch.IsEnabled = true;
        }

    }
}